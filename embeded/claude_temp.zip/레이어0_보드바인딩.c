/* ============================================================
 * 레이어0_보드바인딩.c
 * 역할 : SDK 함수 직접 호출은 오직 이 파일에만 존재한다
 *        상위 레이어는 이 파일의 API만 사용하고 SDK를 모른다
 * ============================================================ */

#include "레이어0_보드바인딩.h"

/* ----------------------------------------------------------
 * 내부 전용 헬퍼 선언 (이 파일 밖에서는 보이지 않음)
 * ---------------------------------------------------------- */
static void     _cs_활성화(보드바인딩_컨텍스트_t *ctx);   /* CS 핀 LOW */
static void     _cs_비활성화(보드바인딩_컨텍스트_t *ctx); /* CS 핀 HIGH */
static bool     _유효한_컨텍스트(const 보드바인딩_컨텍스트_t *ctx);

/* ----------------------------------------------------------
 * 보드바인딩_초기화
 * ---------------------------------------------------------- */
결과코드_t 보드바인딩_초기화(보드바인딩_컨텍스트_t *ctx)
{
    /* 1. 인자 유효성 검사 — NULL 이면 즉시 실패 반환 */
    NULL_이면_반환(ctx, 결과_잘못된_인자);

    /* 2. 이미 초기화된 경우 재진입 방지 */
    if (ctx->초기화_완료) {
        return 결과_성공; /* 멱등성 보장 — 두 번 호출해도 안전 */
    }

    /* 3. SPI 주변장치 초기화 (플랫폼 분기) */
#if defined(플랫폼_STM32)
    /* TODO: HAL_SPI_Init(&hspi1) 또는 CubeMX 핸들 할당 */
    /* ctx->spi_핸들 = &hspi1; */
#elif defined(플랫폼_NRF52)
    /* TODO: nrf_drv_spi_init 호출 */
#elif defined(플랫폼_ESP32)
    /* TODO: spi_bus_initialize + spi_bus_add_device */
#else
    /* 스텁 모드 — 실제 하드웨어 없이 테스트용 */
    ctx->spi_핸들 = (void *)0xDEADBEEF; /* 유효한 척 하는 더미 값 */
#endif

    /* 4. GPIO 핀 방향 설정 (CS, RESET 은 출력, INT 는 입력) */
    /* TODO: 플랫폼별 GPIO 초기화 코드 삽입 */

    /* 5. 틱 함수 포인터 연결 — 플랫폼 타이머 래퍼 지정 */
    ctx->틱_읽기_fn = 보드바인딩_틱_ms;

    /* 6. CS 핀을 기본 비활성(HIGH)으로 설정 */
    보드바인딩_GPIO_출력(ctx, ctx->spi_cs_핀, 1);

    /* 7. 초기화 완료 플래그 설정 */
    ctx->초기화_완료 = true;

    디버그_출력("보드바인딩 초기화 완료, SPI 속도=%lu Hz", ctx->spi_속도_hz);
    return 결과_성공;
}

/* ----------------------------------------------------------
 * 보드바인딩_SPI_전송
 * ---------------------------------------------------------- */
결과코드_t 보드바인딩_SPI_전송(보드바인딩_컨텍스트_t *ctx,
                               const uint8_t *tx_buf,
                               uint8_t       *rx_buf,
                               size_t         len,
                               uint32_t       timeout_ms)
{
    결과코드_t 결과 = 결과_실패;

    /* 1. 컨텍스트와 버퍼 유효성 확인 */
    NULL_이면_반환(ctx,    결과_잘못된_인자);
    NULL_이면_반환(tx_buf, 결과_잘못된_인자);
    if (!ctx->초기화_완료) return 결과_초기화_안됨;
    if (len == 0)          return 결과_잘못된_인자;

    /* 2. CS 핀 LOW — 슬레이브 선택 시작 */
    _cs_활성화(ctx);

    /* 3. 플랫폼별 SPI 전송 실행 */
#if defined(플랫폼_STM32)
    /* HAL_StatusTypeDef hal_ret;
       hal_ret = HAL_SPI_TransmitReceive(ctx->spi_핸들,
                                         (uint8_t *)tx_buf, rx_buf,
                                         (uint16_t)len, timeout_ms);
       결과 = (hal_ret == HAL_OK) ? 결과_성공 : 결과_하드웨어_오류; */
#elif defined(플랫폼_NRF52)
    /* nrf_drv_spi_transfer 호출 후 에러 코드 매핑 */
#elif defined(플랫폼_ESP32)
    /* spi_transaction_t 구조체 채우고 spi_device_polling_transmit 호출 */
#else
    /* 스텁 모드 — 에코 동작 (tx = rx 로 복사) */
    if (rx_buf != NULL) {
        for (size_t i = 0; i < len; i++) rx_buf[i] = tx_buf[i];
    }
    미사용_인자(timeout_ms);
    결과 = 결과_성공;
#endif

    /* 4. CS 핀 HIGH — 슬레이브 선택 해제 */
    _cs_비활성화(ctx);

    return 결과;
}

/* ----------------------------------------------------------
 * 보드바인딩_GPIO_출력
 * ---------------------------------------------------------- */
결과코드_t 보드바인딩_GPIO_출력(보드바인딩_컨텍스트_t *ctx,
                                uint8_t 핀,
                                uint8_t 값)
{
    NULL_이면_반환(ctx, 결과_잘못된_인자);

    /* 플랫폼별 GPIO 쓰기 함수 호출 */
#if defined(플랫폼_STM32)
    /* HAL_GPIO_WritePin(GPIOx, 핀, 값 ? GPIO_PIN_SET : GPIO_PIN_RESET); */
#elif defined(플랫폼_NRF52)
    /* nrf_gpio_pin_write(핀, 값); */
#elif defined(플랫폼_ESP32)
    /* gpio_set_level((gpio_num_t)핀, 값); */
#else
    미사용_인자(핀);
    미사용_인자(값);
    /* 스텁 — 실제 핀 없음, 로그만 출력 */
    디버그_출력("GPIO 출력: 핀=%d, 값=%d", 핀, 값);
#endif

    return 결과_성공;
}

/* ----------------------------------------------------------
 * 보드바인딩_GPIO_읽기
 * ---------------------------------------------------------- */
결과코드_t 보드바인딩_GPIO_읽기(보드바인딩_컨텍스트_t *ctx,
                                uint8_t 핀,
                                uint8_t *출력)
{
    NULL_이면_반환(ctx,  결과_잘못된_인자);
    NULL_이면_반환(출력, 결과_잘못된_인자);

#if defined(플랫폼_STM32)
    /* *출력 = (uint8_t)HAL_GPIO_ReadPin(GPIOx, 핀); */
#elif defined(플랫폼_NRF52)
    /* *출력 = (uint8_t)nrf_gpio_pin_read(핀); */
#elif defined(플랫폼_ESP32)
    /* *출력 = (uint8_t)gpio_get_level((gpio_num_t)핀); */
#else
    미사용_인자(핀);
    *출력 = 0; /* 스텁 — 항상 LOW 반환 */
#endif

    return 결과_성공;
}

/* ----------------------------------------------------------
 * 보드바인딩_지연_ms
 * ---------------------------------------------------------- */
void 보드바인딩_지연_ms(uint32_t ms)
{
#if defined(플랫폼_STM32)
    /* HAL_Delay(ms); */
    /* RTOS 사용 시: osDelay(ms) 또는 vTaskDelay(pdMS_TO_TICKS(ms)) */
#elif defined(플랫폼_NRF52)
    /* nrf_delay_ms(ms); */
#elif defined(플랫폼_ESP32)
    /* vTaskDelay(pdMS_TO_TICKS(ms)); */
#else
    /* 호스트 스텁 — busy-wait 없이 그냥 통과 */
    미사용_인자(ms);
#endif
}

/* ----------------------------------------------------------
 * 보드바인딩_틱_ms
 * ---------------------------------------------------------- */
시각_ms_t 보드바인딩_틱_ms(void)
{
#if defined(플랫폼_STM32)
    /* return (시각_ms_t)HAL_GetTick(); */
#elif defined(플랫폼_NRF52)
    /* return (시각_ms_t)app_timer_cnt_get() / 33; */ /* 32768Hz 기준 변환 */
#elif defined(플랫폼_ESP32)
    /* return (시각_ms_t)(esp_timer_get_time() / 1000); */
#else
    /* 스텁 — 카운터를 매번 수동 증가 (테스트용) */
    static 시각_ms_t _틱 = 0;
    return _틱++; /* 단위 테스트에서 시간 흐름 시뮬레이션 */
#endif
    return 0; /* 도달 불가 — 컴파일러 경고 방지 */
}

/* ----------------------------------------------------------
 * 보드바인딩_인터럽트_등록
 * ---------------------------------------------------------- */
결과코드_t 보드바인딩_인터럽트_등록(보드바인딩_컨텍스트_t *ctx,
                                    void (*콜백)(void *인자),
                                    void *인자)
{
    NULL_이면_반환(ctx,  결과_잘못된_인자);
    NULL_이면_반환(콜백, 결과_잘못된_인자);

    /* ISR 내부 처리 최소화 원칙
     *  - 콜백은 플래그 세트 또는 큐 push 만 수행
     *  - 실제 데이터 처리는 서비스 레이어의 주기 함수로 위임 */

#if defined(플랫폼_STM32)
    /* NVIC 설정 및 HAL_GPIO_EXTI_Callback 연결 */
    /* 콜백 포인터를 전역 배열에 저장해 EXTI 핸들러에서 호출 */
#elif defined(플랫폼_NRF52)
    /* nrf_drv_gpiote_in_config_t 설정 후 nrf_drv_gpiote_in_init 호출 */
#elif defined(플랫폼_ESP32)
    /* gpio_install_isr_service + gpio_isr_handler_add */
#else
    미사용_인자(인자);
    디버그_출력("인터럽트 등록 (스텁): 핀=%d", ctx->인터럽트_핀);
#endif

    return 결과_성공;
}

/* ==========================================================
 * 내부 헬퍼 구현
 * ========================================================== */

static void _cs_활성화(보드바인딩_컨텍스트_t *ctx)
{
    /* CS 핀을 LOW 로 내려 슬레이브에게 통신 시작을 알린다 */
    보드바인딩_GPIO_출력(ctx, ctx->spi_cs_핀, 0);
    /* 셋업 타임이 필요한 슬레이브라면 여기서 수 ns ~ us 지연 추가 */
}

static void _cs_비활성화(보드바인딩_컨텍스트_t *ctx)
{
    /* CS 핀을 HIGH 로 올려 통신 종료를 알린다 */
    보드바인딩_GPIO_출력(ctx, ctx->spi_cs_핀, 1);
}

static bool _유효한_컨텍스트(const 보드바인딩_컨텍스트_t *ctx)
{
    /* NULL 이거나 초기화 안 된 경우 false 반환 */
    미사용_인자(ctx);  /* 현재는 단순 NULL 검사만 사용 */
    return (ctx != NULL) && (ctx->초기화_완료);
}
