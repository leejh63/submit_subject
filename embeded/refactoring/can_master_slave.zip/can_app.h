#ifndef CAN_APP_H
#define CAN_APP_H

#include <stdint.h>

#include "can_types.h"
#include "can_service.h"
#include "app_ctrl_command.h"
#include "app_ctrl_command_mailbox.h"
#include "app_ctrl_result_box.h"

#define CAN_APP_DEFAULT_MAX_SUBMIT_PER_TICK   2U
#define CAN_APP_DEFAULT_MAX_OUTPUT_PER_TICK   4U

typedef void (*CanAppRemoteCommandCallback)(const CanMessage *message, void *context);

typedef struct
{
    uint8_t     initialized;
    uint8_t     localNodeId;
    uint8_t     role;
    uint8_t     defaultTargetNodeId;

    AppCtrlCommandMailbox *commandMailbox;
    AppCtrlResultBox      *resultBox;
    CanAppRemoteCommandCallback remoteCommandCallback;
    void                      *remoteCommandContext;
    uint8_t                maxSubmitPerTick;
    uint8_t                maxOutputPerTick;
    uint8_t                lastActivity;

    CanService  service;

    uint32_t    localSubmitOkCount;
    uint32_t    localSubmitFailCount;
    uint32_t    remoteCommandCount;
    uint32_t    resultConvertCount;
    uint32_t    eventConvertCount;
    uint32_t    textConvertCount;
    uint32_t    resultDropCount;
} CanApp;

uint8_t CanApp_Init(CanApp *app,
                    uint8_t localNodeId,
                    uint8_t role,
                    uint8_t defaultTargetNodeId);

void    CanApp_BindIo(CanApp *app,
                      AppCtrlCommandMailbox *commandMailbox,
                      AppCtrlResultBox *resultBox);
void    CanApp_SetRemoteCommandCallback(CanApp *app,
                                        CanAppRemoteCommandCallback callback,
                                        void *context);

uint8_t CanApp_Task(CanApp *app, uint32_t nowMs);
void    CanApp_FlushTx(CanApp *app, uint32_t nowMs);
uint8_t CanApp_SubmitAppCtrlCommand(CanApp *app, const AppCtrlCommand *cmd);

#endif
