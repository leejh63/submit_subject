#include "runtime.h"

#include <stddef.h>
#include <stdio.h>

#include "sdk_project_config.h"
#include "runtime_task.h"
#include "runtime_status.h"
#include "runtime_tick.h"
#include "app_uart_console.h"
#include "app_ctrl_input.h"
#include "uart_service.h"
#include "app_ctrl_command_mailbox.h"
#include "app_ctrl_result_box.h"
#include "can_types.h"
#include "can_app.h"

/*
 * master node and slave node 1 share this runtime.
 * slave node 2 is handled in sdk_slave_red.
 */
#define RUNTIME_ROLE_MASTER      1U
#define RUNTIME_ROLE_SLAVE       2U

#define RUNTIME_ROLE             RUNTIME_ROLE_MASTER

/*
 * Keep these disabled until the generated LIN/ADC SDK pieces are added
 * to this project. Button/CAN logic works without extra switches.
 */
#ifndef RUNTIME_ENABLE_MASTER_LIN
#define RUNTIME_ENABLE_MASTER_LIN    1U
#endif

#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
#include "lin_driver.h"
#include "peripherals_lin_1.h"
#endif

#define RUNTIME_MASTER_NODE_ID       1U
#define RUNTIME_SLAVE1_NODE_ID       2U

#define RUNTIME_SLAVE1_BUTTON_PIN    12U
#define RUNTIME_SLAVE1_BUTTON_MASK   (1UL << RUNTIME_SLAVE1_BUTTON_PIN)
#define RUNTIME_SLAVE1_BUTTON_PORT   PTC

#define RUNTIME_LIN_XCVR_ENABLE_PIN        9U
#define RUNTIME_LIN_XCVR_ENABLE_MASK       (1UL << RUNTIME_LIN_XCVR_ENABLE_PIN)
#define RUNTIME_LIN_XCVR_ENABLE_GPIO_PORT  PTE

#define RUNTIME_SLAVE1_LED_RED_PIN      15U
#define RUNTIME_SLAVE1_LED_GREEN_PIN    16U
#define RUNTIME_SLAVE1_LED_GPIO_PORT    PTD
#define RUNTIME_SLAVE1_LED_RED_MASK     (1UL << RUNTIME_SLAVE1_LED_RED_PIN)
#define RUNTIME_SLAVE1_LED_GREEN_MASK   (1UL << RUNTIME_SLAVE1_LED_GREEN_PIN)
#define RUNTIME_LED_ACTIVE_ON           0U
#define RUNTIME_LED_ACTIVE_OFF          1U
#define RUNTIME_SLAVE1_LED_TASK_PERIOD_MS   100U
#define RUNTIME_SLAVE1_OK_BLINK_TOGGLES     6U

#define RUNTIME_MASTER_LIN_ADC_PID            0x24U
#define RUNTIME_MASTER_LIN_OK_PID             0x25U
#define RUNTIME_MASTER_LIN_DATA_SIZE          8U
#define RUNTIME_MASTER_LIN_OK_DATA_SIZE       1U
#define RUNTIME_MASTER_LIN_TIMEOUT_TICKS      100U
#define RUNTIME_MASTER_LIN_POLL_PERIOD_MS     20U
#define RUNTIME_MASTER_LIN_OK_TOKEN           0xA5U

#define RUNTIME_ADC_RANGE_MAX                 4096U
#define RUNTIME_ADC_SAFE_MAX                  (RUNTIME_ADC_RANGE_MAX / 3U)
#define RUNTIME_ADC_WARNING_MAX               ((RUNTIME_ADC_RANGE_MAX * 2U) / 3U)
#define RUNTIME_ADC_EMERGENCY_MIN             ((RUNTIME_ADC_RANGE_MAX * 5U) / 6U)
/*
 * These values describe the actual counter geometry used by lin_master_callback().
 * Default them to the "500 microseconds" LPTMR setup:
 * - compare value units: microseconds
 * - compare value: 500 us
 * - input clock: 8 MHz
 * => the SDK selects the lowest prescaler, so the effective timer geometry is
 *    typically 4000 ticks per 500 us (8 ticks/us).
 *
 * If you instead use the old LIN project style:
 * - compare value: 1999 ticks
 * - input clock: 8 MHz
 * - prescaler: divide by 2
 * then override these macros to 2000 / 4.
 */
#ifndef RUNTIME_LIN_TIMER_COMPARE_TICKS
#define RUNTIME_LIN_TIMER_COMPARE_TICKS       4000U
#endif
#ifndef RUNTIME_LIN_TIMER_TICKS_PER_US
#define RUNTIME_LIN_TIMER_TICKS_PER_US        8U
#endif

#if (RUNTIME_ROLE == RUNTIME_ROLE_MASTER)
#define RUNTIME_NODE_ID              RUNTIME_MASTER_NODE_ID
#define RUNTIME_DEFAULT_TARGET_ID    CAN_NODE_ID_INVALID
#define RUNTIME_APP_ROLE             CAN_APP_ROLE_MASTER
#elif (RUNTIME_ROLE == RUNTIME_ROLE_SLAVE)
#define RUNTIME_NODE_ID              RUNTIME_SLAVE1_NODE_ID
#define RUNTIME_DEFAULT_TARGET_ID    CAN_NODE_ID_INVALID
#define RUNTIME_APP_ROLE             CAN_APP_ROLE_SLAVE
#else
#error Invalid RUNTIME_ROLE
#endif

static uint32_t               g_runtimeLastTickMs = 0U;

static AppUartConsoleContext  g_runtimeUartNode;
static RuntimeStatus          g_runtimeStatus;
static AppCtrlCommandMailbox  g_runtimeAppCtrlCommandMailbox;
static AppCtrlResultBox       g_runtimeAppCtrlResultBox;
static CanApp                 g_runtimeCanApp;
static uint8_t                g_runtimeMasterEmergencyActive = 0U;
static uint8_t                g_runtimeMasterSlave1OkPending = 0U;
static char                   g_runtimeModeText[32] = "waiting";
static char                   g_runtimeButtonText[32] = "waiting";
static char                   g_runtimeAdcText[48] = "waiting";
static char                   g_runtimeCanInputText[48] = "waiting";
static char                   g_runtimeLinInputText[48] = "waiting";
static char                   g_runtimeLinConnectionText[32] = "waiting";

typedef enum
{
    RUNTIME_SLAVE1_LED_MODE_OFF = 0U,
    RUNTIME_SLAVE1_LED_MODE_EMERGENCY,
    RUNTIME_SLAVE1_LED_MODE_ACK_BLINK
} RuntimeSlave1LedMode;

static RuntimeSlave1LedMode   g_runtimeSlave1LedMode = RUNTIME_SLAVE1_LED_MODE_OFF;
static uint8_t                g_runtimeSlave1BlinkToggleCount = 0U;
static uint8_t                g_runtimeSlave1BlinkGreenOn = 0U;

typedef enum
{
    RUNTIME_LIN_ZONE_SAFE = 0U,
    RUNTIME_LIN_ZONE_WARNING,
    RUNTIME_LIN_ZONE_DANGER,
    RUNTIME_LIN_ZONE_EMERGENCY
} RuntimeLinZone;

static void Runtime_TaskUart(void *context);
static void Runtime_TaskMasterLin(void *context);
static void Runtime_TaskSlave1Button(void *context);
static void Runtime_TaskSlave1Led(void *context);
static void Runtime_TaskMasterLinPoll(void *context);
static void Runtime_TaskMasterLinBridge(void *context);
static void Runtime_TaskCan(void *context);
static void Runtime_TaskHeartbeat(void *context);
static void Runtime_TaskRender(void *context);

static void Runtime_UpdateTaskRender(AppUartConsoleContext *node);
static void Runtime_RefreshStatusView(void);
static void Runtime_RefreshInputView(void);
static void Runtime_SetModeText(const char *text);
static void Runtime_SetButtonText(const char *text);
static void Runtime_SetAdcText(const char *text);
static void Runtime_SetCanInputText(const char *text);
static void Runtime_SetLinInputText(const char *text);
static void Runtime_SetLinConnectionText(const char *text);
static RuntimeLinZone Runtime_MasterClassifyZone(uint16_t adcValue);
static const char *Runtime_MasterZoneText(RuntimeLinZone zone);
static void Runtime_UpdateMasterAdcView(uint16_t adcValue,
                                        RuntimeLinZone zone,
                                        uint8_t emergencyLatched);
static const char *Runtime_MasterEmergencyText(uint8_t emergencyActive);
static void Runtime_MasterLinTransceiverInit(void);
static void Runtime_Slave1LedInit(void);
static void Runtime_Slave1SetOff(void);
static void Runtime_Slave1SetRed(void);
static void Runtime_Slave1SetGreen(uint8_t on);
static void Runtime_Slave1StartAckBlink(void);
static void Runtime_Slave1ApplyCanCommand(uint8_t commandCode, uint8_t sourceNodeId);
#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
static void Runtime_MasterHandleSlave1OkRequest(void);
#endif
static void Runtime_CanRemoteCommandCallback(const CanMessage *message, void *context);
static uint8_t Runtime_SubmitCanCommandCode(uint8_t commandCode,
                                            uint8_t targetNodeId,
                                            uint8_t needResponse);
#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
static void Runtime_MasterLinTickHook(void);
#endif

static RuntimeTaskEntry g_runtimeTaskTable[] =
{
    {
        "uart",
        1U,
        0U,
        Runtime_TaskUart,
        &g_runtimeUartNode
    },
    {
        "lin",
        1U,
        0U,
        Runtime_TaskMasterLin,
        NULL
    },
    {
        "button",
        10U,
        0U,
        Runtime_TaskSlave1Button,
        NULL
    },
    {
        "slave_led",
        RUNTIME_SLAVE1_LED_TASK_PERIOD_MS,
        0U,
        Runtime_TaskSlave1Led,
        NULL
    },
    {
        "lin_poll",
        RUNTIME_MASTER_LIN_POLL_PERIOD_MS,
        0U,
        Runtime_TaskMasterLinPoll,
        NULL
    },
    {
        "lin_bridge",
        RUNTIME_MASTER_LIN_POLL_PERIOD_MS,
        0U,
        Runtime_TaskMasterLinBridge,
        NULL
    },
    {
        "can",
        10U,
        0U,
        Runtime_TaskCan,
        NULL
    },
    {
        "heartbeat",
        1000U,
        0U,
        Runtime_TaskHeartbeat,
        NULL
    },
    {
        "render",
        100U,
        0U,
        Runtime_TaskRender,
        &g_runtimeUartNode
    },
};

#define RUNTIME_TASK_COUNT \
    ((uint32_t)(sizeof(g_runtimeTaskTable) / sizeof(g_runtimeTaskTable[0])))

static void Runtime_TaskHeartbeat(void *context)
{
    (void)context;

    g_runtimeStatus.tmp_check_heartbeat++;
    RuntimeStatus_SetHeartbeatAlive(&g_runtimeStatus, 1U);
    RuntimeStatus_SetTickMs(&g_runtimeStatus, RuntimeTick_GetMs());
}

static void Runtime_TaskUart(void *context)
{
    AppUartConsoleContext *node;
    uint32_t nowMs;

    node = (AppUartConsoleContext *)context;
    if (node == NULL)
    {
        return;
    }

    g_runtimeStatus.tmp_check_uart++;
    nowMs = RuntimeTick_GetMs();
    AppUartConsole_Task(node, nowMs);
}

static void Runtime_TaskRender(void *context)
{
    AppUartConsoleContext *node;

    node = (AppUartConsoleContext *)context;
    if (node == NULL)
    {
        return;
    }

    Runtime_UpdateTaskRender(node);
    AppUartConsole_RenderTask(node);
}

static void Runtime_UpdateTaskRender(AppUartConsoleContext *node)
{
    char taskText[APP_UART_CONSOLE_TASK_VIEW_SIZE];
    const char *heartbeatText;
    const char *canText;
    const char *uartText;

    if (node == NULL)
        return;

    if (UartService_HasError(&node->uart) != 0U)
        RuntimeStatus_SetUartOk(&g_runtimeStatus, 0U);
    else
        RuntimeStatus_SetUartOk(&g_runtimeStatus, 1U);

    RuntimeStatus_SetTickMs(&g_runtimeStatus, RuntimeTick_GetMs());

    heartbeatText = (g_runtimeStatus.heartbeatAlive != 0U) ? "alive" : "idle";
    canText = (g_runtimeStatus.canAlive != 0U) ? "ok" : "idle";
    uartText = (g_runtimeStatus.uartOk != 0U) ? "ok" : "error";

    (void)snprintf(taskText,
                   sizeof(taskText),
                   "HeartBeat : %s / %lu\r\n"
                   "CAN       : %s / %lu\r\n"
                   "LIN       : %s\r\n"
                   "UART      : %s / %lu",
                   heartbeatText,
                   (unsigned long)g_runtimeStatus.tmp_check_heartbeat,
                   canText,
                   (unsigned long)g_runtimeStatus.tmp_check_can,
                   g_runtimeLinConnectionText,
                   uartText,
                   (unsigned long)g_runtimeStatus.tmp_check_uart);

    AppUartConsole_SetTaskText(node, taskText);
    Runtime_RefreshStatusView();
    Runtime_RefreshInputView();
}

static void Runtime_RefreshStatusView(void)
{
    char valueText[APP_UART_CONSOLE_VALUE_VIEW_SIZE];

    (void)snprintf(valueText,
                   sizeof(valueText),
                   "Mode   : %s\r\n"
                   "Button : %s\r\n"
                   "ADC    : %s",
                   g_runtimeModeText,
                   g_runtimeButtonText,
                   g_runtimeAdcText);

    AppUartConsole_SetValueText(&g_runtimeUartNode, valueText);
}

static void Runtime_RefreshInputView(void)
{
    char sourceText[APP_UART_CONSOLE_SOURCE_VIEW_SIZE];

    (void)snprintf(sourceText,
                   sizeof(sourceText),
                   "from [can] \"%s\"\r\n"
                   "from [lin] \"%s\"",
                   g_runtimeCanInputText,
                   g_runtimeLinInputText);

    AppUartConsole_SetSourceText(&g_runtimeUartNode, sourceText);
}

static void Runtime_SetModeText(const char *text)
{
    if (text == NULL)
        return;

    (void)snprintf(g_runtimeModeText, sizeof(g_runtimeModeText), "%s", text);
}

static void Runtime_SetButtonText(const char *text)
{
    if (text == NULL)
        return;

    (void)snprintf(g_runtimeButtonText, sizeof(g_runtimeButtonText), "%s", text);
}

static void Runtime_SetAdcText(const char *text)
{
    if (text == NULL)
        return;

    (void)snprintf(g_runtimeAdcText, sizeof(g_runtimeAdcText), "%s", text);
}

static void Runtime_SetCanInputText(const char *text)
{
    if (text == NULL)
        return;

    (void)snprintf(g_runtimeCanInputText, sizeof(g_runtimeCanInputText), "%s", text);
}

static void Runtime_SetLinInputText(const char *text)
{
    if (text == NULL)
        return;

    (void)snprintf(g_runtimeLinInputText, sizeof(g_runtimeLinInputText), "%s", text);
}

static void Runtime_SetLinConnectionText(const char *text)
{
    if (text == NULL)
        return;

    (void)snprintf(g_runtimeLinConnectionText,
                   sizeof(g_runtimeLinConnectionText),
                   "%s",
                   text);
}

static RuntimeLinZone Runtime_MasterClassifyZone(uint16_t adcValue)
{
    if (adcValue < RUNTIME_ADC_SAFE_MAX)
        return RUNTIME_LIN_ZONE_SAFE;

    if (adcValue < RUNTIME_ADC_WARNING_MAX)
        return RUNTIME_LIN_ZONE_WARNING;

    if (adcValue < RUNTIME_ADC_EMERGENCY_MIN)
        return RUNTIME_LIN_ZONE_DANGER;

    return RUNTIME_LIN_ZONE_EMERGENCY;
}

static const char *Runtime_MasterZoneText(RuntimeLinZone zone)
{
    switch (zone)
    {
        case RUNTIME_LIN_ZONE_SAFE:
            return "safe";
        case RUNTIME_LIN_ZONE_WARNING:
            return "warning";
        case RUNTIME_LIN_ZONE_DANGER:
            return "danger";
        case RUNTIME_LIN_ZONE_EMERGENCY:
            return "emergency";
        default:
            return "unknown";
    }
}

static void Runtime_UpdateMasterAdcView(uint16_t adcValue,
                                        RuntimeLinZone zone,
                                        uint8_t emergencyLatched)
{
    char adcText[48];
    char linText[48];

    (void)snprintf(adcText,
                   sizeof(adcText),
                   "%u (%s, lock=%u)",
                   (unsigned int)adcValue,
                   Runtime_MasterZoneText(zone),
                   (unsigned int)emergencyLatched);
    Runtime_SetAdcText(adcText);

    (void)snprintf(linText,
                   sizeof(linText),
                   "adc in : %u (%s)",
                   (unsigned int)adcValue,
                   Runtime_MasterZoneText(zone));
    Runtime_SetLinInputText(linText);
    Runtime_SetLinConnectionText("ok");
}

static const char *Runtime_MasterEmergencyText(uint8_t emergencyActive)
{
    return (emergencyActive != 0U) ? "emergency" : "normal";
}

static void Runtime_MasterLinTransceiverInit(void)
{
    if ((RUNTIME_ENABLE_MASTER_LIN == 0U) || (RUNTIME_ROLE != RUNTIME_ROLE_MASTER))
        return;

    PINS_DRV_SetPinsDirection(RUNTIME_LIN_XCVR_ENABLE_GPIO_PORT,
                              RUNTIME_LIN_XCVR_ENABLE_MASK);
    PINS_DRV_SetPins(RUNTIME_LIN_XCVR_ENABLE_GPIO_PORT,
                     RUNTIME_LIN_XCVR_ENABLE_MASK);
}

static void Runtime_Slave1LedInit(void)
{
    if (RUNTIME_ROLE != RUNTIME_ROLE_SLAVE)
        return;

    PINS_DRV_SetPinsDirection(RUNTIME_SLAVE1_LED_GPIO_PORT,
                              RUNTIME_SLAVE1_LED_RED_MASK | RUNTIME_SLAVE1_LED_GREEN_MASK);
    PINS_DRV_WritePin(RUNTIME_SLAVE1_LED_GPIO_PORT,
                      RUNTIME_SLAVE1_LED_RED_PIN,
                      RUNTIME_LED_ACTIVE_OFF);
    PINS_DRV_WritePin(RUNTIME_SLAVE1_LED_GPIO_PORT,
                      RUNTIME_SLAVE1_LED_GREEN_PIN,
                      RUNTIME_LED_ACTIVE_OFF);

    g_runtimeSlave1LedMode = RUNTIME_SLAVE1_LED_MODE_OFF;
    g_runtimeSlave1BlinkToggleCount = 0U;
    g_runtimeSlave1BlinkGreenOn = 0U;
}

static void Runtime_Slave1SetOff(void)
{
    if (RUNTIME_ROLE != RUNTIME_ROLE_SLAVE)
        return;

    PINS_DRV_WritePin(RUNTIME_SLAVE1_LED_GPIO_PORT,
                      RUNTIME_SLAVE1_LED_RED_PIN,
                      RUNTIME_LED_ACTIVE_OFF);
    PINS_DRV_WritePin(RUNTIME_SLAVE1_LED_GPIO_PORT,
                      RUNTIME_SLAVE1_LED_GREEN_PIN,
                      RUNTIME_LED_ACTIVE_OFF);
}

static void Runtime_Slave1SetRed(void)
{
    if (RUNTIME_ROLE != RUNTIME_ROLE_SLAVE)
        return;

    PINS_DRV_WritePin(RUNTIME_SLAVE1_LED_GPIO_PORT,
                      RUNTIME_SLAVE1_LED_RED_PIN,
                      RUNTIME_LED_ACTIVE_ON);
    PINS_DRV_WritePin(RUNTIME_SLAVE1_LED_GPIO_PORT,
                      RUNTIME_SLAVE1_LED_GREEN_PIN,
                      RUNTIME_LED_ACTIVE_OFF);
}

static void Runtime_Slave1SetGreen(uint8_t on)
{
    if (RUNTIME_ROLE != RUNTIME_ROLE_SLAVE)
        return;

    PINS_DRV_WritePin(RUNTIME_SLAVE1_LED_GPIO_PORT,
                      RUNTIME_SLAVE1_LED_RED_PIN,
                      RUNTIME_LED_ACTIVE_OFF);
    PINS_DRV_WritePin(RUNTIME_SLAVE1_LED_GPIO_PORT,
                      RUNTIME_SLAVE1_LED_GREEN_PIN,
                      (on != 0U) ? RUNTIME_LED_ACTIVE_ON : RUNTIME_LED_ACTIVE_OFF);
}

static void Runtime_Slave1StartAckBlink(void)
{
    if (RUNTIME_ROLE != RUNTIME_ROLE_SLAVE)
        return;

    g_runtimeSlave1LedMode = RUNTIME_SLAVE1_LED_MODE_ACK_BLINK;
    g_runtimeSlave1BlinkToggleCount = 0U;
    g_runtimeSlave1BlinkGreenOn = 1U;
    Runtime_Slave1SetGreen(1U);
}

static void Runtime_Slave1ApplyCanCommand(uint8_t commandCode, uint8_t sourceNodeId)
{
    char canText[48];

    if (RUNTIME_ROLE != RUNTIME_ROLE_SLAVE)
        return;

    switch (commandCode)
    {
        case CAN_CMD_EMERGENCY:
            g_runtimeSlave1LedMode = RUNTIME_SLAVE1_LED_MODE_EMERGENCY;
            g_runtimeSlave1BlinkToggleCount = 0U;
            g_runtimeSlave1BlinkGreenOn = 0U;
            Runtime_Slave1SetRed();
            Runtime_SetModeText("emergency");
            Runtime_SetButtonText("press ok");
            Runtime_SetAdcText("n/a");
            (void)snprintf(canText,
                           sizeof(canText),
                           "emergency in (%u)",
                           (unsigned int)sourceNodeId);
            Runtime_SetCanInputText(canText);
            break;

        case CAN_CMD_OK:
            Runtime_Slave1StartAckBlink();
            Runtime_SetModeText("ack blink");
            Runtime_SetButtonText("approved");
            Runtime_SetAdcText("n/a");
            (void)snprintf(canText,
                           sizeof(canText),
                           "ok in (%u)",
                           (unsigned int)sourceNodeId);
            Runtime_SetCanInputText(canText);
            break;

        case CAN_CMD_OFF:
            g_runtimeSlave1LedMode = RUNTIME_SLAVE1_LED_MODE_OFF;
            Runtime_Slave1SetOff();
            Runtime_SetModeText("normal");
            Runtime_SetButtonText("waiting");
            Runtime_SetAdcText("n/a");
            break;

        case CAN_CMD_OPEN:
        case CAN_CMD_CLOSE:
        case CAN_CMD_TEST:
            (void)snprintf(canText,
                           sizeof(canText),
                           "cmd %u in (%u)",
                           (unsigned int)commandCode,
                           (unsigned int)sourceNodeId);
            Runtime_SetCanInputText(canText);
            break;

        default:
            break;
    }
}

static void Runtime_CanRemoteCommandCallback(const CanMessage *message, void *context)
{
    (void)context;

    if (message == NULL)
        return;

    if (RUNTIME_ROLE == RUNTIME_ROLE_SLAVE)
    {
        Runtime_Slave1ApplyCanCommand(message->payload[0], message->sourceNodeId);
        return;
    }

    if ((RUNTIME_ROLE == RUNTIME_ROLE_MASTER) &&
        (message->sourceNodeId == RUNTIME_SLAVE1_NODE_ID) &&
        (message->payload[0] == CAN_CMD_OK))
    {
        Runtime_SetCanInputText("button in");
        Runtime_SetButtonText("request");
#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
        Runtime_MasterHandleSlave1OkRequest();
#else
        AppUartConsole_SetResultText(&g_runtimeUartNode, "[wait] lin disabled");
#endif
    }
}

static uint8_t Runtime_SubmitCanCommandCode(uint8_t commandCode,
                                            uint8_t targetNodeId,
                                            uint8_t needResponse)
{
    if (CanService_SendCommand(&g_runtimeCanApp.service,
                               targetNodeId,
                               commandCode,
                               0U,
                               0U,
                               needResponse) == 0U)
        return 0U;

    CanService_FlushTx(&g_runtimeCanApp.service, RuntimeTick_GetMs());
    return 1U;
}

static void Runtime_TaskCan(void *context)
{
    uint32_t nowMs;
    uint8_t  activity;

    (void)context;

    nowMs = RuntimeTick_GetMs();
    activity = CanApp_Task(&g_runtimeCanApp, nowMs);

    RuntimeStatus_SetCanAlive(&g_runtimeStatus, activity);
    if (activity != 0U)
        g_runtimeStatus.tmp_check_can++;
}

static void Runtime_TaskSlave1Led(void *context)
{
    (void)context;

    if (RUNTIME_ROLE != RUNTIME_ROLE_SLAVE)
        return;

    if (g_runtimeSlave1LedMode != RUNTIME_SLAVE1_LED_MODE_ACK_BLINK)
        return;

    g_runtimeSlave1BlinkToggleCount++;
    if ((g_runtimeSlave1BlinkToggleCount % 2U) == 0U)
    {
        g_runtimeSlave1BlinkGreenOn = 1U;
    }
    else
    {
        g_runtimeSlave1BlinkGreenOn = 0U;
    }

    if (g_runtimeSlave1BlinkToggleCount >= RUNTIME_SLAVE1_OK_BLINK_TOGGLES)
    {
        g_runtimeSlave1LedMode = RUNTIME_SLAVE1_LED_MODE_OFF;
        g_runtimeSlave1BlinkToggleCount = 0U;
        g_runtimeSlave1BlinkGreenOn = 0U;
        Runtime_Slave1SetOff();
        Runtime_SetModeText("normal");
        Runtime_SetButtonText("waiting");
        return;
    }

    Runtime_Slave1SetGreen(g_runtimeSlave1BlinkGreenOn);
}

static void Runtime_TaskSlave1Button(void *context)
{
    static uint8_t lastSamplePressed = 0U;
    static uint8_t stablePressed = 0U;
    static uint8_t sameSampleCount = 0U;
    uint8_t rawPressed;

    (void)context;

    if (RUNTIME_ROLE != RUNTIME_ROLE_SLAVE)
        return;

    rawPressed = ((PINS_DRV_ReadPins(RUNTIME_SLAVE1_BUTTON_PORT) &
                   RUNTIME_SLAVE1_BUTTON_MASK) == 0U) ? 1U : 0U;

    if (rawPressed == lastSamplePressed)
    {
        if (sameSampleCount < 3U)
            sameSampleCount++;
    }
    else
    {
        sameSampleCount = 0U;
        lastSamplePressed = rawPressed;
        return;
    }

    if (sameSampleCount < 2U)
        return;

    if (stablePressed == rawPressed)
        return;

    stablePressed = rawPressed;
    if (stablePressed == 0U)
        return;

    if (g_runtimeSlave1LedMode != RUNTIME_SLAVE1_LED_MODE_EMERGENCY)
        return;

    Runtime_SetButtonText("pressed");
    (void)Runtime_SubmitCanCommandCode(CAN_CMD_OK,
                                       RUNTIME_MASTER_NODE_ID,
                                       0U);
    AppUartConsole_SetResultText(&g_runtimeUartNode, "[can] ok request sent");
}

#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
typedef enum
{
    RUNTIME_LIN_MASTER_IDLE = 0,
    RUNTIME_LIN_MASTER_WAIT_PID,
    RUNTIME_LIN_MASTER_WAIT_RX,
    RUNTIME_LIN_MASTER_WAIT_TX
} RuntimeLinMasterState;

#define RUNTIME_LIN_FLAG_PID_OK   (1UL << 0)
#define RUNTIME_LIN_FLAG_RX_DONE  (1UL << 1)
#define RUNTIME_LIN_FLAG_TX_DONE  (1UL << 2)
#define RUNTIME_LIN_FLAG_ERROR    (1UL << 3)

static RuntimeLinMasterState g_runtimeLinState = RUNTIME_LIN_MASTER_IDLE;
static volatile uint32_t     g_runtimeLinFlags = 0U;
static uint8_t               g_runtimeLinRxBuffer[RUNTIME_MASTER_LIN_DATA_SIZE];
static uint8_t               g_runtimeLinTxBuffer[RUNTIME_MASTER_LIN_OK_DATA_SIZE];
static uint8_t               g_runtimeLinRequestedPid = 0U;
static uint32_t              g_runtimeLinLastPollMs = 0U;
static uint16_t              g_runtimeLinLatestAdc = 0U;
static RuntimeLinZone        g_runtimeLinLatestZone = RUNTIME_LIN_ZONE_SAFE;
static uint8_t               g_runtimeLinEmergencyLatched = 0U;
static uint8_t               g_runtimeLinHasValidStatus = 0U;
static uint8_t               g_runtimeLinHasFreshStatus = 0U;
static uint8_t               g_runtimeLinOkTxPending = 0U;
static RuntimeLinZone        g_runtimeLinLastReportedZone = (RuntimeLinZone)0xFFU;
static uint8_t               g_runtimeLinLastReportedLock = 0xFFU;
static volatile uint32_t     g_runtimeLinTimerOverflowCount = 0U;
static volatile uint8_t      g_runtimeLinInitialized = 0U;

static void Runtime_MasterHandleSlave1OkRequest(void)
{
    if (g_runtimeLinHasValidStatus == 0U)
    {
        Runtime_SetButtonText("waiting lin");
        AppUartConsole_SetResultText(&g_runtimeUartNode, "[wait] no lin status");
        return;
    }

    if (g_runtimeLinLatestZone == RUNTIME_LIN_ZONE_EMERGENCY)
    {
        g_runtimeMasterSlave1OkPending = 0U;
        Runtime_SetButtonText("denied");
        AppUartConsole_SetResultText(&g_runtimeUartNode, "[deny] adc still emergency");
        return;
    }

    if (g_runtimeLinEmergencyLatched == 0U)
    {
        g_runtimeMasterSlave1OkPending = 0U;
        Runtime_SetButtonText("already clear");
        AppUartConsole_SetResultText(&g_runtimeUartNode, "[info] slave not locked");
        return;
    }

    g_runtimeMasterSlave1OkPending = 1U;
    g_runtimeLinTxBuffer[0] = RUNTIME_MASTER_LIN_OK_TOKEN;
    g_runtimeLinOkTxPending = 1U;
    Runtime_SetButtonText("ok queued");
    Runtime_SetLinConnectionText("ok pending");
    AppUartConsole_SetResultText(&g_runtimeUartNode, "[queued] slave1 ok -> lin ok");
}

uint32_t lin_master_callback(uint32_t *ns)
{
    static uint32_t previousCountValue = 0UL;
    uint32_t counterValue;

    counterValue = LPTMR_DRV_GetCounterValueByCount(INST_LPTMR_1);

    if (ns != NULL)
    {
        *ns = ((uint32_t)(counterValue +
                (g_runtimeLinTimerOverflowCount * RUNTIME_LIN_TIMER_COMPARE_TICKS) -
                previousCountValue)) * 1000UL / RUNTIME_LIN_TIMER_TICKS_PER_US;
    }

    g_runtimeLinTimerOverflowCount = 0U;
    previousCountValue = counterValue;

    return 0U;
}

static void Runtime_MasterLinTickHook(void)
{
    if (g_runtimeLinInitialized == 0U)
        return;

    LIN_DRV_TimeoutService(INST_LIN2);
    g_runtimeLinTimerOverflowCount++;
}

static void Runtime_MasterLinCallback(uint32_t instance, void *linStatePtr)
{
    lin_state_t *linState;

    (void)instance;

    linState = (lin_state_t *)linStatePtr;
    if (linState == NULL)
        return;

    if (linState->timeoutCounterFlag != false)
    {
        linState->timeoutCounterFlag = false;
        g_runtimeLinFlags |= RUNTIME_LIN_FLAG_ERROR;
        return;
    }

    switch (linState->currentEventId)
    {
        case LIN_PID_OK:
            g_runtimeLinFlags |= RUNTIME_LIN_FLAG_PID_OK;
            break;

        case LIN_RX_COMPLETED:
            g_runtimeLinFlags |= RUNTIME_LIN_FLAG_RX_DONE;
            break;

        case LIN_TX_COMPLETED:
            g_runtimeLinFlags |= RUNTIME_LIN_FLAG_TX_DONE;
            break;

        case LIN_PID_ERROR:
        case LIN_CHECKSUM_ERROR:
        case LIN_READBACK_ERROR:
        case LIN_FRAME_ERROR:
            g_runtimeLinFlags |= RUNTIME_LIN_FLAG_ERROR;
            break;

        default:
            break;
    }
}

static void Runtime_MasterLinGoIdle(void)
{
    (void)LIN_DRV_GotoIdleState(INST_LIN2);
    g_runtimeLinState = RUNTIME_LIN_MASTER_IDLE;
    g_runtimeLinRequestedPid = 0U;
}

static void Runtime_MasterLinStart(uint8_t pid)
{
    status_t status;

    if (g_runtimeLinState != RUNTIME_LIN_MASTER_IDLE)
        return;

    status = LIN_DRV_MasterSendHeader(INST_LIN2, pid);
    if (status != STATUS_SUCCESS)
    {
        Runtime_SetLinConnectionText("header fail");
        AppUartConsole_SetResultText(&g_runtimeUartNode, "[error] lin header fail");
        Runtime_MasterLinGoIdle();
        return;
    }

    g_runtimeLinRequestedPid = pid;
    g_runtimeLinState = RUNTIME_LIN_MASTER_WAIT_PID;
    Runtime_SetLinConnectionText((pid == RUNTIME_MASTER_LIN_OK_PID) ? "ok tx..." : "polling");
}

static void Runtime_MasterLinHandleRxDone(void)
{
    uint16_t adcValue;
    RuntimeLinZone zone;
    uint8_t emergencyLatched;
    uint8_t emergencyActive;

    adcValue = (uint16_t)g_runtimeLinRxBuffer[0] |
               (uint16_t)((uint16_t)g_runtimeLinRxBuffer[1] << 8U);
    if (adcValue > 4095U)
        adcValue = 4095U;

    zone = Runtime_MasterClassifyZone(adcValue);
    if (g_runtimeLinRxBuffer[2] <= (uint8_t)RUNTIME_LIN_ZONE_EMERGENCY)
        zone = (RuntimeLinZone)g_runtimeLinRxBuffer[2];

    emergencyLatched = (g_runtimeLinRxBuffer[3] != 0U) ? 1U : 0U;

    g_runtimeLinLatestAdc = adcValue;
    g_runtimeLinLatestZone = zone;
    g_runtimeLinEmergencyLatched = emergencyLatched;
    g_runtimeLinHasValidStatus = 1U;
    g_runtimeLinHasFreshStatus = 1U;
    Runtime_UpdateMasterAdcView(adcValue, zone, emergencyLatched);

    emergencyActive = ((zone == RUNTIME_LIN_ZONE_EMERGENCY) ||
                       (emergencyLatched != 0U)) ? 1U : 0U;
    Runtime_SetModeText(Runtime_MasterEmergencyText(emergencyActive));

    if (emergencyActive != g_runtimeMasterEmergencyActive)
    {
        char stateText[APP_CTRL_RESULT_TEXT_SIZE];

        g_runtimeMasterEmergencyActive = emergencyActive;
        (void)snprintf(stateText,
                       sizeof(stateText),
                       "[state] %s",
                       Runtime_MasterEmergencyText(emergencyActive));
        AppUartConsole_SetResultText(&g_runtimeUartNode, stateText);

        if (emergencyActive != 0U)
        {
            g_runtimeMasterSlave1OkPending = 0U;
            Runtime_SetButtonText("waiting");
            if (Runtime_SubmitCanCommandCode(CAN_CMD_EMERGENCY,
                                             RUNTIME_SLAVE1_NODE_ID,
                                             0U) != 0U)
            {
                AppUartConsole_SetResultText(&g_runtimeUartNode,
                                             "[can] emergency -> slave1");
            }
        }
    }

    if ((g_runtimeLinLastReportedZone != zone) ||
        (g_runtimeLinLastReportedLock != emergencyLatched))
    {
        char resultText[APP_CTRL_RESULT_TEXT_SIZE];

        (void)snprintf(resultText,
                       sizeof(resultText),
                       "[lin] %s lock=%u adc=%u",
                       Runtime_MasterZoneText(zone),
                       (unsigned int)emergencyLatched,
                       (unsigned int)adcValue);
        AppUartConsole_SetResultText(&g_runtimeUartNode, resultText);
        g_runtimeLinLastReportedZone = zone;
        g_runtimeLinLastReportedLock = emergencyLatched;
    }

    if ((g_runtimeMasterSlave1OkPending != 0U) &&
        (zone == RUNTIME_LIN_ZONE_EMERGENCY))
    {
        g_runtimeMasterSlave1OkPending = 0U;
        g_runtimeLinOkTxPending = 0U;
        Runtime_SetButtonText("cancelled");
        Runtime_SetLinConnectionText("emergency");
        AppUartConsole_SetResultText(&g_runtimeUartNode, "[cancel] ok request cleared");
    }

    if ((g_runtimeMasterSlave1OkPending != 0U) &&
        (zone != RUNTIME_LIN_ZONE_EMERGENCY) &&
        (emergencyLatched == 0U))
    {
        if (Runtime_SubmitCanCommandCode(CAN_CMD_OK,
                                         RUNTIME_SLAVE1_NODE_ID,
                                         0U) != 0U)
        {
            g_runtimeMasterSlave1OkPending = 0U;
            Runtime_SetButtonText("approved");
            AppUartConsole_SetResultText(&g_runtimeUartNode, "[can] ok -> slave1");
        }
    }
}

static void Runtime_MasterLinHandleTxDone(void)
{
    if (g_runtimeLinRequestedPid == RUNTIME_MASTER_LIN_OK_PID)
    {
        g_runtimeLinOkTxPending = 0U;
        Runtime_SetLinConnectionText("ok sent");
        AppUartConsole_SetResultText(&g_runtimeUartNode, "[ok] lin ok sent");
    }
}

static void Runtime_MasterLinFsmStep(void)
{
    if ((g_runtimeLinFlags & RUNTIME_LIN_FLAG_ERROR) != 0U)
    {
        g_runtimeLinFlags &= ~RUNTIME_LIN_FLAG_ERROR;
        if (g_runtimeLinRequestedPid == RUNTIME_MASTER_LIN_OK_PID)
        {
            g_runtimeLinOkTxPending = 0U;
            Runtime_SetLinConnectionText("ok failed");
            AppUartConsole_SetResultText(&g_runtimeUartNode, "[error] lin ok failed");
        }
        else
        {
            Runtime_SetLinConnectionText("rx timeout");
            AppUartConsole_SetResultText(&g_runtimeUartNode, "[error] lin rx timeout");
        }
        Runtime_MasterLinGoIdle();
        return;
    }

    if ((g_runtimeLinState == RUNTIME_LIN_MASTER_WAIT_PID) &&
        ((g_runtimeLinFlags & RUNTIME_LIN_FLAG_PID_OK) != 0U))
    {
        g_runtimeLinFlags &= ~RUNTIME_LIN_FLAG_PID_OK;
        LIN_DRV_SetTimeoutCounter(INST_LIN2, RUNTIME_MASTER_LIN_TIMEOUT_TICKS);

        if (g_runtimeLinRequestedPid == RUNTIME_MASTER_LIN_ADC_PID)
        {
            (void)LIN_DRV_ReceiveFrameData(INST_LIN2,
                                           g_runtimeLinRxBuffer,
                                           (uint8_t)sizeof(g_runtimeLinRxBuffer));
            g_runtimeLinState = RUNTIME_LIN_MASTER_WAIT_RX;
            return;
        }

        if (g_runtimeLinRequestedPid == RUNTIME_MASTER_LIN_OK_PID)
        {
            if (LIN_DRV_SendFrameData(INST_LIN2,
                                      g_runtimeLinTxBuffer,
                                      RUNTIME_MASTER_LIN_OK_DATA_SIZE) != STATUS_SUCCESS)
            {
                g_runtimeLinOkTxPending = 0U;
                Runtime_SetLinConnectionText("ok send fail");
                AppUartConsole_SetResultText(&g_runtimeUartNode, "[error] lin ok send");
                Runtime_MasterLinGoIdle();
                return;
            }

            g_runtimeLinState = RUNTIME_LIN_MASTER_WAIT_TX;
            return;
        }

        Runtime_MasterLinGoIdle();
        return;
    }

    if ((g_runtimeLinState == RUNTIME_LIN_MASTER_WAIT_RX) &&
        ((g_runtimeLinFlags & RUNTIME_LIN_FLAG_RX_DONE) != 0U))
    {
        g_runtimeLinFlags &= ~RUNTIME_LIN_FLAG_RX_DONE;
        Runtime_MasterLinHandleRxDone();
        Runtime_MasterLinGoIdle();
        return;
    }

    if ((g_runtimeLinState == RUNTIME_LIN_MASTER_WAIT_TX) &&
        ((g_runtimeLinFlags & RUNTIME_LIN_FLAG_TX_DONE) != 0U))
    {
        g_runtimeLinFlags &= ~RUNTIME_LIN_FLAG_TX_DONE;
        Runtime_MasterLinHandleTxDone();
        Runtime_MasterLinGoIdle();
        return;
    }
}
#endif

static void Runtime_TaskMasterLin(void *context)
{
    (void)context;

#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
    if (RUNTIME_ROLE != RUNTIME_ROLE_MASTER)
        return;

    Runtime_MasterLinFsmStep();
#else
    (void)context;
#endif
}

static void Runtime_TaskMasterLinPoll(void *context)
{
    (void)context;

#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
    uint32_t nowMs;

    if (RUNTIME_ROLE != RUNTIME_ROLE_MASTER)
        return;

    nowMs = RuntimeTick_GetMs();
    if ((nowMs - g_runtimeLinLastPollMs) < RUNTIME_MASTER_LIN_POLL_PERIOD_MS)
        return;

    g_runtimeLinLastPollMs = nowMs;
    if (g_runtimeLinOkTxPending != 0U)
    {
        Runtime_MasterLinStart(RUNTIME_MASTER_LIN_OK_PID);
        return;
    }

    Runtime_MasterLinStart(RUNTIME_MASTER_LIN_ADC_PID);
#else
    (void)context;
#endif
}

static void Runtime_TaskMasterLinBridge(void *context)
{
    (void)context;

#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
    uint8_t localOkRequested;

    if (RUNTIME_ROLE != RUNTIME_ROLE_MASTER)
        return;

    localOkRequested = AppCtrlInput_ConsumeLocalOkRequest();
    if (localOkRequested != 0U)
    {
        if (g_runtimeLinHasValidStatus == 0U)
        {
            AppUartConsole_SetResultText(&g_runtimeUartNode, "[wait] no lin status");
        }
        else if (g_runtimeLinLatestZone == RUNTIME_LIN_ZONE_EMERGENCY)
        {
            AppUartConsole_SetResultText(&g_runtimeUartNode, "[deny] adc still emergency");
        }
        else if (g_runtimeLinEmergencyLatched == 0U)
        {
            AppUartConsole_SetResultText(&g_runtimeUartNode, "[info] slave not locked");
        }
        else
        {
            g_runtimeLinTxBuffer[0] = RUNTIME_MASTER_LIN_OK_TOKEN;
            g_runtimeLinOkTxPending = 1U;
            Runtime_SetLinConnectionText("ok pending");
            AppUartConsole_SetResultText(&g_runtimeUartNode, "[queued] lin ok");
        }
    }

    if (g_runtimeMasterSlave1OkPending == 0U)
        return;

    if (g_runtimeLinHasValidStatus == 0U)
        return;

    if (g_runtimeLinLatestZone == RUNTIME_LIN_ZONE_EMERGENCY)
    {
        g_runtimeMasterSlave1OkPending = 0U;
        return;
    }

    if (g_runtimeLinEmergencyLatched != 0U)
    {
        if (g_runtimeLinOkTxPending == 0U)
        {
            g_runtimeLinTxBuffer[0] = RUNTIME_MASTER_LIN_OK_TOKEN;
            g_runtimeLinOkTxPending = 1U;
            Runtime_SetButtonText("ok queued");
            Runtime_SetLinConnectionText("ok pending");
            AppUartConsole_SetResultText(&g_runtimeUartNode, "[queued] slave1 ok -> lin ok");
        }
        return;
    }

    if (Runtime_SubmitCanCommandCode(CAN_CMD_OK,
                                     RUNTIME_SLAVE1_NODE_ID,
                                     0U) != 0U)
    {
        g_runtimeMasterSlave1OkPending = 0U;
        Runtime_SetButtonText("approved");
        AppUartConsole_SetResultText(&g_runtimeUartNode, "[can] ok -> slave1");
    }
#else
    (void)context;
#endif
}

status_t Runtime_Init(void)
{
    status_t status;

    RuntimeStatus_Init(&g_runtimeStatus);
    RuntimeTick_SetIsrHook(NULL);

    status = RuntimeTick_Init();
    if (status != STATUS_SUCCESS)
        return status;

    g_runtimeLastTickMs = RuntimeTick_GetMs();

    AppCtrlCommandMailbox_Init(&g_runtimeAppCtrlCommandMailbox);
    AppCtrlResultBox_Init(&g_runtimeAppCtrlResultBox);

    status = AppUartConsole_Init(&g_runtimeUartNode,
                                 &g_runtimeAppCtrlCommandMailbox,
                                 &g_runtimeAppCtrlResultBox,
                                 (uint8_t)RUNTIME_NODE_ID);
    if (status != STATUS_SUCCESS)
        return status;

    if (CanApp_Init(&g_runtimeCanApp,
                    (uint8_t)RUNTIME_NODE_ID,
                    (uint8_t)RUNTIME_APP_ROLE,
                    (uint8_t)RUNTIME_DEFAULT_TARGET_ID) == 0U)
    {
        return STATUS_ERROR;
    }

    CanApp_BindIo(&g_runtimeCanApp,
                  &g_runtimeAppCtrlCommandMailbox,
                  &g_runtimeAppCtrlResultBox);
    CanApp_SetRemoteCommandCallback(&g_runtimeCanApp,
                                    Runtime_CanRemoteCommandCallback,
                                    NULL);
    Runtime_MasterLinTransceiverInit();
    g_runtimeMasterEmergencyActive = 0U;
    g_runtimeMasterSlave1OkPending = 0U;

    if (RUNTIME_ROLE == RUNTIME_ROLE_MASTER)
    {
        Runtime_SetModeText("normal");
        Runtime_SetButtonText("waiting");
        Runtime_SetAdcText("waiting");
        Runtime_SetCanInputText("waiting");
        Runtime_SetLinInputText("waiting");
        Runtime_SetLinConnectionText("waiting");
    }
    else
    {
        Runtime_SetModeText("normal");
        Runtime_SetButtonText("ready");
        Runtime_SetAdcText("n/a");
        Runtime_SetCanInputText("waiting");
        Runtime_SetLinInputText("n/a");
        Runtime_SetLinConnectionText("n/a");
    }

    Runtime_Slave1LedInit();

#if (RUNTIME_ENABLE_MASTER_LIN != 0U)
    if (RUNTIME_ROLE == RUNTIME_ROLE_MASTER)
    {
        status = LIN_DRV_Init(INST_LIN2, &lin2_InitConfig0, &lin2_State);
        if (status != STATUS_SUCCESS)
            return status;

        (void)LIN_DRV_InstallCallback(INST_LIN2, Runtime_MasterLinCallback);
        g_runtimeLinState = RUNTIME_LIN_MASTER_IDLE;
        g_runtimeLinFlags = 0U;
        g_runtimeLinRequestedPid = 0U;
        g_runtimeLinLastPollMs = 0U;
        g_runtimeLinLatestAdc = 0U;
        g_runtimeLinLatestZone = RUNTIME_LIN_ZONE_SAFE;
        g_runtimeLinEmergencyLatched = 0U;
        g_runtimeLinHasValidStatus = 0U;
        g_runtimeLinHasFreshStatus = 0U;
        g_runtimeLinOkTxPending = 0U;
        g_runtimeLinLastReportedZone = (RuntimeLinZone)0xFFU;
        g_runtimeLinLastReportedLock = 0xFFU;
        g_runtimeLinTimerOverflowCount = 0U;
        g_runtimeLinInitialized = 1U;
        RuntimeTick_SetIsrHook(Runtime_MasterLinTickHook);
    }
#endif

    Runtime_UpdateTaskRender(&g_runtimeUartNode);

    return STATUS_SUCCESS;
}

void Runtime_Run(void)
{
    uint32_t currentTickMs;

    currentTickMs = RuntimeTick_GetMs();

    while (g_runtimeLastTickMs != currentTickMs)
    {
        g_runtimeLastTickMs++;

        RuntimeTask_RunTable(g_runtimeTaskTable,
                             RUNTIME_TASK_COUNT,
                             g_runtimeLastTickMs);
    }
}

void Runtime_FaultLoop(void)
{
    for (;;)
    {
        /* fault loop */
    }
}
