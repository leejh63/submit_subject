#ifndef RUNTIME_TICK_H
#define RUNTIME_TICK_H

#include <stdint.h>

#include "status.h"

/*
 * 시스템의 millisecond soft tick 인터페이스.
 * LPTMR interrupt를 0.5ms base로 사용하고, 그 위에서 1ms soft tick을 만든다.
 */

#ifndef RUNTIME_TICK_ISR_PERIOD_US
#define RUNTIME_TICK_ISR_PERIOD_US  500U
#endif

typedef void (*RuntimeTickIsrHook)(void);

/* tick 타이머와 IRQ를 초기화한다. */
status_t RuntimeTick_Init(void);

/* 현재 누적 tick(ms)을 반환한다. */
uint32_t RuntimeTick_GetMs(void);

/* 현재 base interrupt tick count를 반환한다. */
uint32_t RuntimeTick_GetBaseTickCount(void);

/* LPTMR ISR마다 함께 호출할 hook을 등록한다. */
void RuntimeTick_SetIsrHook(RuntimeTickIsrHook hook);

#endif
