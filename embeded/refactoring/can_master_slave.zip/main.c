/*!
** Copyright 2020 NXP
** @file main.c
** @brief
**         Main module.
*/

#include "sdk_project_config.h"
#include "runtime.h"

int main(void)
{
    status_t status;

    CLOCK_SYS_Init(g_clockManConfigsArr,
                   CLOCK_MANAGER_CONFIG_CNT,
                   g_clockManCallbacksArr,
                   CLOCK_MANAGER_CALLBACK_CNT);

    CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);

    PINS_DRV_Init(NUM_OF_CONFIGURED_PINS0, g_pin_mux_InitConfigArr0);

    status = Runtime_Init();
    if (status != STATUS_SUCCESS)
    {
        Runtime_FaultLoop();
    }

    for (;;)
    {
        Runtime_Run();
    }
}
