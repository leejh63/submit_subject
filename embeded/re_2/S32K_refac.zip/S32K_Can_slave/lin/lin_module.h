#ifndef LIN_MODULE_H
#define LIN_MODULE_H

#include "infra/infra_types.h"

typedef enum
{
    LIN_ROLE_MASTER = 1,
    LIN_ROLE_SLAVE = 2
} LinRole;

typedef enum
{
    LIN_EVENT_NONE = 0,
    LIN_EVENT_PID_OK,
    LIN_EVENT_RX_DONE,
    LIN_EVENT_TX_DONE,
    LIN_EVENT_ERROR
} LinEventId;

typedef enum
{
    LIN_ZONE_SAFE = 0,
    LIN_ZONE_WARNING,
    LIN_ZONE_DANGER,
    LIN_ZONE_EMERGENCY
} LinZone;

typedef InfraStatus (*LinHwInitFn)(void *context);
typedef InfraStatus (*LinHwMasterSendHeaderFn)(void *context, uint8_t pid);
typedef InfraStatus (*LinHwStartReceiveFn)(void *context, uint8_t *buffer, uint8_t length);
typedef InfraStatus (*LinHwStartSendFn)(void *context, const uint8_t *buffer, uint8_t length);
typedef void (*LinHwGotoIdleFn)(void *context);
typedef void (*LinHwSetTimeoutFn)(void *context, uint16_t timeout_ticks);
typedef void (*LinHwServiceTickFn)(void *context);

typedef struct
{
    LinHwInitFn             init_fn;
    LinHwMasterSendHeaderFn master_send_header_fn;
    LinHwStartReceiveFn     start_receive_fn;
    LinHwStartSendFn        start_send_fn;
    LinHwGotoIdleFn         goto_idle_fn;
    LinHwSetTimeoutFn       set_timeout_fn;
    LinHwServiceTickFn      service_tick_fn;
    void                   *context;
} LinBinding;

typedef struct
{
    uint16_t adc_value;
    uint8_t  zone;
    uint8_t  emergency_latched;
    uint8_t  valid;
    uint8_t  fresh;
} LinStatusFrame;

typedef struct
{
    uint8_t    role;
    uint8_t    pid_status;
    uint8_t    pid_ok;
    uint8_t    ok_token;
    uint8_t    status_frame_size;
    uint8_t    ok_frame_size;
    uint16_t   timeout_ticks;
    uint32_t   poll_period_ms;
    LinBinding binding;
} LinConfig;

typedef struct
{
    uint8_t       initialized;
    LinConfig     config;
    volatile uint8_t  state;
    volatile uint32_t flags;
    volatile uint8_t  current_pid;
    uint32_t      last_poll_ms;
    volatile uint8_t  ok_tx_pending;
    volatile uint8_t  ok_token_pending;
    uint8_t       rx_buffer[8];
    uint8_t       tx_buffer[8];
    LinStatusFrame latest_status;
    LinStatusFrame slave_status_cache;
} LinModule;

InfraStatus LinModule_Init(LinModule *module, const LinConfig *config);
void        LinModule_OnBaseTick(LinModule *module);
void        LinModule_OnEvent(LinModule *module, LinEventId event_id, uint8_t current_pid);
void        LinModule_TaskFast(LinModule *module, uint32_t now_ms);
void        LinModule_TaskPoll(LinModule *module, uint32_t now_ms);
InfraStatus LinModule_RequestOk(LinModule *module);
uint8_t     LinModule_GetLatestStatus(const LinModule *module, LinStatusFrame *out_status);
uint8_t     LinModule_ConsumeFreshStatus(LinModule *module, LinStatusFrame *out_status);
void        LinModule_SetSlaveStatus(LinModule *module, const LinStatusFrame *status);
uint8_t     LinModule_ConsumeSlaveOkToken(LinModule *module);

#endif
