#ifndef INFRA_TYPES_H
#define INFRA_TYPES_H

#include <stddef.h>
#include <stdint.h>

#define INFRA_ARRAY_COUNT(array_) \
    ((uint32_t)(sizeof(array_) / sizeof((array_)[0])))

typedef enum
{
    INFRA_STATUS_OK = 0,
    INFRA_STATUS_BUSY,
    INFRA_STATUS_EMPTY,
    INFRA_STATUS_FULL,
    INFRA_STATUS_TIMEOUT,
    INFRA_STATUS_INVALID_ARG,
    INFRA_STATUS_NOT_READY,
    INFRA_STATUS_IO_ERROR,
    INFRA_STATUS_UNSUPPORTED
} InfraStatus;

static inline uint32_t Infra_TimeElapsedMs(uint32_t now_ms, uint32_t start_ms)
{
    return (uint32_t)(now_ms - start_ms);
}

static inline uint8_t Infra_TimeIsExpired(uint32_t now_ms,
                                          uint32_t start_ms,
                                          uint32_t timeout_ms)
{
    return (Infra_TimeElapsedMs(now_ms, start_ms) >= timeout_ms) ? 1U : 0U;
}

static inline uint8_t Infra_TimeIsDue(uint32_t now_ms,
                                      uint32_t last_run_ms,
                                      uint32_t period_ms)
{
    if (period_ms == 0U)
    {
        return 0U;
    }

    return (Infra_TimeElapsedMs(now_ms, last_run_ms) >= period_ms) ? 1U : 0U;
}

#endif
