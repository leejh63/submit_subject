#include "runtime_task.h"

#include <stddef.h>

void RuntimeTask_ResetTable(RuntimeTaskEntry *table,
                            uint32_t task_count,
                            uint32_t start_ms)
{
    uint32_t index;

    if (table == NULL)
    {
        return;
    }

    for (index = 0U; index < task_count; index++)
    {
        table[index].last_run_ms = start_ms;
    }
}

void RuntimeTask_RunDue(RuntimeTaskEntry *table,
                        uint32_t task_count,
                        uint32_t now_ms)
{
    uint32_t index;

    if (table == NULL)
    {
        return;
    }

    for (index = 0U; index < task_count; index++)
    {
        RuntimeTaskEntry *task = &table[index];

        if ((task->task_fn == NULL) || (task->period_ms == 0U))
        {
            continue;
        }

        if (Infra_TimeIsDue(now_ms, task->last_run_ms, task->period_ms) == 0U)
        {
            continue;
        }

        task->last_run_ms = now_ms;
        task->task_fn(task->context, now_ms);
    }
}
