#ifndef INFRA_QUEUE_H
#define INFRA_QUEUE_H

#include "infra_types.h"

typedef struct
{
    uint8_t  *buffer;
    uint16_t  item_size;
    uint16_t  capacity;
    uint16_t  head;
    uint16_t  tail;
    uint16_t  count;
} InfraQueue;

InfraStatus InfraQueue_Init(InfraQueue *queue,
                            void *storage,
                            uint16_t item_size,
                            uint16_t capacity);
void        InfraQueue_Reset(InfraQueue *queue);
InfraStatus InfraQueue_Push(InfraQueue *queue, const void *item);
InfraStatus InfraQueue_Pop(InfraQueue *queue, void *out_item);
InfraStatus InfraQueue_Peek(const InfraQueue *queue, void *out_item);
uint16_t    InfraQueue_GetCount(const InfraQueue *queue);
uint16_t    InfraQueue_GetCapacity(const InfraQueue *queue);
uint8_t     InfraQueue_IsEmpty(const InfraQueue *queue);
uint8_t     InfraQueue_IsFull(const InfraQueue *queue);

#endif
