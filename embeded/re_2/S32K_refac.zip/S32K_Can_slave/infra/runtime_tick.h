#ifndef RUNTIME_TICK_H
#define RUNTIME_TICK_H

#include "infra_types.h"

#ifndef RUNTIME_TICK_ISR_PERIOD_US
#define RUNTIME_TICK_ISR_PERIOD_US  500U
#endif

typedef void (*RuntimeTickHook)(void *context);

InfraStatus RuntimeTick_Init(void);
uint32_t    RuntimeTick_GetMs(void);
uint32_t    RuntimeTick_GetBaseCount(void);
void        RuntimeTick_ClearHooks(void);
InfraStatus RuntimeTick_RegisterHook(RuntimeTickHook hook, void *context);

#endif
