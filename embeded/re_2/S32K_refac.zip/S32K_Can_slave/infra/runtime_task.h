#ifndef RUNTIME_TASK_H
#define RUNTIME_TASK_H

#include "infra_types.h"

typedef void (*RuntimeTaskFn)(void *context, uint32_t now_ms);

typedef struct
{
    const char   *name;
    uint32_t      period_ms;
    uint32_t      last_run_ms;
    RuntimeTaskFn task_fn;
    void         *context;
} RuntimeTaskEntry;

void RuntimeTask_ResetTable(RuntimeTaskEntry *table,
                            uint32_t task_count,
                            uint32_t start_ms);
void RuntimeTask_RunDue(RuntimeTaskEntry *table,
                        uint32_t task_count,
                        uint32_t now_ms);

#endif
