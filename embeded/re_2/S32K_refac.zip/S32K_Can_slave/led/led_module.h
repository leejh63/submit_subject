#ifndef LED_MODULE_H
#define LED_MODULE_H

#include "infra/infra_types.h"

typedef enum
{
    LED_PATTERN_OFF = 0,
    LED_PATTERN_GREEN_SOLID,
    LED_PATTERN_RED_SOLID,
    LED_PATTERN_YELLOW_SOLID,
    LED_PATTERN_RED_BLINK,
    LED_PATTERN_GREEN_BLINK
} LedPattern;

typedef struct
{
    void    *gpio_port;
    uint32_t red_pin;
    uint32_t green_pin;
    uint8_t  active_on_level;
} LedConfig;

typedef struct
{
    uint8_t    initialized;
    LedConfig  config;
    LedPattern pattern;
    uint8_t    output_phase_on;
    uint8_t    finite_blink_enabled;
    uint8_t    blink_toggles_remaining;
} LedModule;

InfraStatus LedModule_Init(LedModule *module, const LedConfig *config);
void        LedModule_SetPattern(LedModule *module, LedPattern pattern);
void        LedModule_StartGreenAckBlink(LedModule *module, uint8_t toggle_count);
void        LedModule_Task(LedModule *module, uint32_t now_ms);
LedPattern  LedModule_GetPattern(const LedModule *module);

#endif
