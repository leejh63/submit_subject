#ifndef ADC_MODULE_H
#define ADC_MODULE_H

#include "infra/infra_types.h"

typedef enum
{
    ADC_ZONE_SAFE = 0,
    ADC_ZONE_WARNING,
    ADC_ZONE_DANGER,
    ADC_ZONE_EMERGENCY
} AdcZone;

typedef InfraStatus (*AdcHwInitFn)(void *context);
typedef InfraStatus (*AdcHwSampleFn)(void *context, uint16_t *out_raw_value);

typedef struct
{
    AdcHwInitFn  init_fn;
    AdcHwSampleFn sample_fn;
    void        *hw_context;
    uint32_t     sample_period_ms;
    uint16_t     range_max;
    uint16_t     safe_max;
    uint16_t     warning_max;
    uint16_t     emergency_min;
    uint8_t      blocking_mode;
} AdcConfig;

typedef struct
{
    uint16_t raw_value;
    uint8_t  zone;
    uint8_t  emergency_latched;
    uint8_t  has_sample;
    uint8_t  sample_error;
} AdcSnapshot;

typedef struct
{
    uint8_t     initialized;
    AdcConfig   config;
    AdcSnapshot snapshot;
    uint32_t    last_sample_ms;
} AdcModule;

InfraStatus AdcModule_Init(AdcModule *module, const AdcConfig *config);
void        AdcModule_Task(AdcModule *module, uint32_t now_ms);
InfraStatus AdcModule_GetSnapshot(const AdcModule *module, AdcSnapshot *out_snapshot);
InfraStatus AdcModule_ClearEmergencyLatch(AdcModule *module);
const char *AdcModule_ZoneText(uint8_t zone);

#endif
