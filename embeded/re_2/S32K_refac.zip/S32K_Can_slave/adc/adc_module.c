#include "adc_module.h"

#include <stddef.h>
#include <string.h>

static uint8_t AdcModule_ClassifyZone(const AdcConfig *config, uint16_t raw_value)
{
    if (raw_value < config->safe_max)
    {
        return ADC_ZONE_SAFE;
    }

    if (raw_value < config->warning_max)
    {
        return ADC_ZONE_WARNING;
    }

    if (raw_value < config->emergency_min)
    {
        return ADC_ZONE_DANGER;
    }

    return ADC_ZONE_EMERGENCY;
}

InfraStatus AdcModule_Init(AdcModule *module, const AdcConfig *config)
{
    InfraStatus status;

    if ((module == NULL) || (config == NULL))
    {
        return INFRA_STATUS_INVALID_ARG;
    }

    (void)memset(module, 0, sizeof(*module));
    module->config = *config;

    if ((module->config.sample_fn == NULL) || (module->config.range_max == 0U))
    {
        return INFRA_STATUS_NOT_READY;
    }

    if (module->config.init_fn != NULL)
    {
        status = module->config.init_fn(module->config.hw_context);
        if (status != INFRA_STATUS_OK)
        {
            return status;
        }
    }

    module->initialized = 1U;
    return INFRA_STATUS_OK;
}

void AdcModule_Task(AdcModule *module, uint32_t now_ms)
{
    InfraStatus status;
    uint16_t    raw_value;
    uint16_t    range_ceiling;

    if ((module == NULL) || (module->initialized == 0U))
    {
        return;
    }

    if (Infra_TimeIsDue(now_ms, module->last_sample_ms, module->config.sample_period_ms) == 0U)
    {
        return;
    }

    module->last_sample_ms = now_ms;
    raw_value = 0U;
    status = module->config.sample_fn(module->config.hw_context, &raw_value);
    if (status != INFRA_STATUS_OK)
    {
        module->snapshot.sample_error = 1U;
        return;
    }

    range_ceiling = (module->config.range_max > 0U) ? (uint16_t)(module->config.range_max - 1U) : 0U;
    if (raw_value > range_ceiling)
    {
        raw_value = range_ceiling;
    }

    module->snapshot.raw_value = raw_value;
    module->snapshot.zone = AdcModule_ClassifyZone(&module->config, raw_value);
    module->snapshot.has_sample = 1U;
    module->snapshot.sample_error = 0U;

    if (module->snapshot.zone == ADC_ZONE_EMERGENCY)
    {
        module->snapshot.emergency_latched = 1U;
    }
}

InfraStatus AdcModule_GetSnapshot(const AdcModule *module, AdcSnapshot *out_snapshot)
{
    if ((module == NULL) || (out_snapshot == NULL) || (module->initialized == 0U))
    {
        return INFRA_STATUS_INVALID_ARG;
    }

    *out_snapshot = module->snapshot;
    return module->snapshot.has_sample != 0U ? INFRA_STATUS_OK : INFRA_STATUS_EMPTY;
}

InfraStatus AdcModule_ClearEmergencyLatch(AdcModule *module)
{
    if ((module == NULL) || (module->initialized == 0U))
    {
        return INFRA_STATUS_INVALID_ARG;
    }

    if (module->snapshot.has_sample == 0U)
    {
        return INFRA_STATUS_EMPTY;
    }

    if (module->snapshot.zone == ADC_ZONE_EMERGENCY)
    {
        return INFRA_STATUS_BUSY;
    }

    module->snapshot.emergency_latched = 0U;
    return INFRA_STATUS_OK;
}

const char *AdcModule_ZoneText(uint8_t zone)
{
    switch (zone)
    {
        case ADC_ZONE_SAFE:
            return "safe";

        case ADC_ZONE_WARNING:
            return "warning";

        case ADC_ZONE_DANGER:
            return "danger";

        case ADC_ZONE_EMERGENCY:
            return "emergency";

        default:
            return "unknown";
    }
}
