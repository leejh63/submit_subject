#ifndef APP_SLAVE2_H
#define APP_SLAVE2_H

#include "app/app_core.h"

InfraStatus AppSlave2_Init(AppCore *app);
void        AppSlave2_HandleLinOkToken(AppCore *app);
void        AppSlave2_TaskAdc(AppCore *app, uint32_t now_ms);

#endif
