#ifndef APP_CORE_INTERNAL_H
#define APP_CORE_INTERNAL_H

#include "app/app_core.h"

#define APP_SLAVE1_MODE_NORMAL     0U
#define APP_SLAVE1_MODE_EMERGENCY  1U
#define APP_SLAVE1_MODE_ACK_BLINK  2U

void        AppCore_SetModeText(AppCore *app, const char *text);
void        AppCore_SetButtonText(AppCore *app, const char *text);
void        AppCore_SetAdcText(AppCore *app, const char *text);
void        AppCore_SetCanInputText(AppCore *app, const char *text);
void        AppCore_SetLinInputText(AppCore *app, const char *text);
void        AppCore_SetLinLinkText(AppCore *app, const char *text);
void        AppCore_SetResultText(AppCore *app, const char *text);
const char *AppCore_GetLinZoneText(uint8_t zone);
uint8_t     AppCore_QueueCanCommandCode(AppCore *app,
                                        uint8_t target_node_id,
                                        uint8_t command_code,
                                        uint8_t need_response);
InfraStatus AppCore_InitConsoleCan(AppCore *app);

#endif
