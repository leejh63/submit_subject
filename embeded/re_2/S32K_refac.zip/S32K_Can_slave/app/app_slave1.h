#ifndef APP_SLAVE1_H
#define APP_SLAVE1_H

#include "app/app_core.h"

InfraStatus AppSlave1_Init(AppCore *app);
void        AppSlave1_HandleCanCommand(AppCore *app,
                                       const CanMessage *message,
                                       uint8_t *out_response_code);
void        AppSlave1_TaskButton(AppCore *app, uint32_t now_ms);
void        AppSlave1_TaskLed(AppCore *app, uint32_t now_ms);

#endif
