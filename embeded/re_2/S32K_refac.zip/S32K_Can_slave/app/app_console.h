#ifndef APP_CONSOLE_H
#define APP_CONSOLE_H

#include "app/app_config.h"
#include "can/can_types.h"
#include "infra/infra_queue.h"
#include "uart/uart_service.h"

typedef enum
{
    APP_CONSOLE_CAN_CMD_NONE = 0,
    APP_CONSOLE_CAN_CMD_OPEN,
    APP_CONSOLE_CAN_CMD_CLOSE,
    APP_CONSOLE_CAN_CMD_OFF,
    APP_CONSOLE_CAN_CMD_TEST,
    APP_CONSOLE_CAN_CMD_TEXT,
    APP_CONSOLE_CAN_CMD_EVENT
} AppConsoleCanCommandType;

typedef struct
{
    uint8_t type;
    uint8_t target_node_id;
    uint8_t target_is_broadcast;
    char    text[CAN_TEXT_MAX_LEN + 1U];
    uint8_t event_code;
    uint8_t arg0;
    uint8_t arg1;
} AppConsoleCanCommand;

typedef enum
{
    APP_CONSOLE_STATE_IDLE = 0,
    APP_CONSOLE_STATE_ERROR
} AppConsoleState;

typedef struct
{
    char    input_text[APP_CONSOLE_INPUT_VIEW_SIZE];
    char    task_text[APP_CONSOLE_TASK_VIEW_SIZE];
    char    source_text[APP_CONSOLE_SOURCE_VIEW_SIZE];
    char    result_text[APP_CONSOLE_RESULT_VIEW_SIZE];
    char    value_text[APP_CONSOLE_VALUE_VIEW_SIZE];
    uint8_t full_refresh_required;
    uint8_t input_dirty;
    uint8_t task_dirty;
    uint8_t source_dirty;
    uint8_t result_dirty;
    uint8_t value_dirty;
    uint8_t layout_drawn;
} AppConsoleView;

typedef struct
{
    uint8_t        initialized;
    uint8_t        node_id;
    AppConsoleState state;
    uint8_t        local_ok_pending;
    UartService    uart;
    InfraQueue     can_cmd_queue;
    AppConsoleCanCommand can_cmd_storage[APP_CONSOLE_CAN_CMD_QUEUE_SIZE];
    AppConsoleView view;
} AppConsole;

InfraStatus AppConsole_Init(AppConsole *console, uint8_t node_id);
void        AppConsole_Task(AppConsole *console, uint32_t now_ms);
void        AppConsole_Render(AppConsole *console);
uint8_t     AppConsole_TryPopCanCommand(AppConsole *console, AppConsoleCanCommand *out_cmd);
uint8_t     AppConsole_ConsumeLocalOk(AppConsole *console);
void        AppConsole_SetTaskText(AppConsole *console, const char *text);
void        AppConsole_SetSourceText(AppConsole *console, const char *text);
void        AppConsole_SetResultText(AppConsole *console, const char *text);
void        AppConsole_SetValueText(AppConsole *console, const char *text);
uint8_t     AppConsole_IsError(const AppConsole *console);

#endif
