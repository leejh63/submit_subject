#ifndef APP_MASTER_H
#define APP_MASTER_H

#include "app/app_core.h"

InfraStatus AppMaster_Init(AppCore *app);
void        AppMaster_RequestOk(AppCore *app);
void        AppMaster_HandleFreshLinStatus(AppCore *app, const LinStatusFrame *status);
void        AppMaster_HandleCanCommand(AppCore *app,
                                       const CanMessage *message,
                                       uint8_t *out_response_code);
void        AppMaster_AfterLinPoll(AppCore *app);

#endif
