#ifndef CAN_SERVICE_H
#define CAN_SERVICE_H

#include "infra/infra_types.h"
#include "can_hw.h"
#include "can_proto.h"

typedef struct
{
    uint8_t  in_use;
    uint8_t  request_id;
    uint8_t  target_node_id;
    uint8_t  command_code;
    uint32_t start_tick_ms;
    uint32_t timeout_ms;
} CanPendingRequest;

typedef struct
{
    uint8_t initialized;
    uint8_t tx_in_flight;
    uint8_t last_error;
    CanHw   hw;
    CanFrame tx_queue[CAN_TRANSPORT_TX_QUEUE_SIZE];
    uint8_t  tx_head;
    uint8_t  tx_tail;
    uint8_t  tx_count;
    CanFrame rx_queue[CAN_TRANSPORT_RX_QUEUE_SIZE];
    uint8_t  rx_head;
    uint8_t  rx_tail;
    uint8_t  rx_count;
    CanFrame current_tx_frame;
    uint32_t hw_tx_ok_count_seen;
    uint32_t hw_tx_error_count_seen;
} CanTransport;

typedef struct
{
    uint8_t initialized;
    uint8_t local_node_id;
    uint8_t next_request_id;
    uint8_t last_error;
    uint32_t default_timeout_ms;
    uint32_t current_tick_ms;
    CanProto proto;
    CanTransport transport;
    CanPendingRequest pending_table[CAN_SERVICE_PENDING_SIZE];
    CanMessage incoming_queue[CAN_SERVICE_QUEUE_SIZE];
    uint8_t    incoming_head;
    uint8_t    incoming_tail;
    uint8_t    incoming_count;
    CanServiceResult result_queue[CAN_SERVICE_QUEUE_SIZE];
    uint8_t          result_head;
    uint8_t          result_tail;
    uint8_t          result_count;
} CanService;

uint8_t CanService_Init(CanService *service,
                        uint8_t local_node_id,
                        uint32_t default_timeout_ms);
void    CanService_Task(CanService *service, uint32_t now_ms);
void    CanService_FlushTx(CanService *service, uint32_t now_ms);
uint8_t CanService_SendCommand(CanService *service,
                               uint8_t target_node_id,
                               uint8_t command_code,
                               uint8_t arg0,
                               uint8_t arg1,
                               uint8_t need_response);
uint8_t CanService_SendResponse(CanService *service,
                                uint8_t target_node_id,
                                uint8_t request_id,
                                uint8_t result_code,
                                uint8_t detail_code);
uint8_t CanService_SendEvent(CanService *service,
                             uint8_t target_node_id,
                             uint8_t event_code,
                             uint8_t arg0,
                             uint8_t arg1);
uint8_t CanService_SendText(CanService *service,
                            uint8_t target_node_id,
                            uint8_t text_type,
                            const char *text);
uint8_t CanService_PopReceivedMessage(CanService *service, CanMessage *out_message);
uint8_t CanService_PopResult(CanService *service, CanServiceResult *out_result);

#endif
