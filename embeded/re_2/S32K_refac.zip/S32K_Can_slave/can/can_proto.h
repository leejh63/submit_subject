#ifndef CAN_PROTO_H
#define CAN_PROTO_H

#include "can_types.h"

typedef struct
{
    uint8_t local_node_id;
} CanProtoConfig;

typedef struct
{
    CanFrame frames[1];
    uint8_t  count;
} CanEncodedFrameList;

typedef struct
{
    uint8_t  initialized;
    uint8_t  local_node_id;
    uint32_t decode_ok_count;
    uint32_t decode_ignored_count;
    uint32_t decode_invalid_count;
    uint32_t decode_unsupported_count;
} CanProto;

uint8_t              CanProto_Init(CanProto *proto, const CanProtoConfig *config);
uint8_t              CanProto_EncodeMessage(CanProto *proto,
                                            const CanMessage *message,
                                            CanEncodedFrameList *out_list);
CanProtoDecodeStatus CanProto_DecodeFrame(CanProto *proto,
                                          const CanFrame *frame,
                                          CanMessage *out_message);

#endif
