#ifndef CAN_HW_H
#define CAN_HW_H

#include "can_types.h"

typedef struct
{
    uint8_t  initialized;
    uint8_t  local_node_id;
    uint8_t  instance;
    uint8_t  tx_mb_index;
    uint8_t  rx_mb_index;
    uint8_t  tx_busy;
    uint8_t  last_error;
    CanFrame rx_queue[CAN_HW_RX_QUEUE_SIZE];
    uint8_t  rx_head;
    uint8_t  rx_tail;
    uint8_t  rx_count;
    uint32_t tx_ok_count;
    uint32_t tx_error_count;
    uint32_t rx_ok_count;
    uint32_t rx_error_count;
    uint32_t rx_drop_count;
} CanHw;

uint8_t CanHw_InitDefault(CanHw *hw, uint8_t local_node_id);
void    CanHw_Task(CanHw *hw, uint32_t now_ms);
uint8_t CanHw_StartTx(CanHw *hw, const CanFrame *frame);
uint8_t CanHw_TryPopRx(CanHw *hw, CanFrame *out_frame);
uint8_t CanHw_IsReady(const CanHw *hw);
uint8_t CanHw_IsTxBusy(const CanHw *hw);
uint8_t CanHw_GetLastError(const CanHw *hw);

#endif
