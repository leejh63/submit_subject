#ifndef CAN_MODULE_H
#define CAN_MODULE_H

#include "infra/infra_queue.h"
#include "can_service.h"

typedef enum
{
    CAN_MODULE_REQUEST_COMMAND = 0,
    CAN_MODULE_REQUEST_RESPONSE,
    CAN_MODULE_REQUEST_EVENT,
    CAN_MODULE_REQUEST_TEXT
} CanModuleRequestKind;

typedef struct
{
    uint8_t kind;
    uint8_t target_node_id;
    uint8_t code0;
    uint8_t code1;
    uint8_t code2;
    uint8_t need_response;
    char    text[CAN_TEXT_MAX_LEN + 1U];
} CanModuleRequest;

typedef struct
{
    uint8_t   local_node_id;
    uint8_t   default_target_node_id;
    uint32_t  default_timeout_ms;
    uint8_t   max_submit_per_tick;
} CanModuleConfig;

typedef struct
{
    uint8_t          initialized;
    uint8_t          local_node_id;
    uint8_t          default_target_node_id;
    uint8_t          max_submit_per_tick;
    uint8_t          last_activity;
    CanService       service;
    InfraQueue       request_queue;
    CanModuleRequest request_storage[CAN_MODULE_REQUEST_QUEUE_SIZE];
} CanModule;

InfraStatus CanModule_Init(CanModule *module, const CanModuleConfig *config);
void        CanModule_Task(CanModule *module, uint32_t now_ms);
InfraStatus CanModule_QueueCommand(CanModule *module,
                                   uint8_t target_node_id,
                                   uint8_t command_code,
                                   uint8_t arg0,
                                   uint8_t arg1,
                                   uint8_t need_response);
InfraStatus CanModule_QueueResponse(CanModule *module,
                                    uint8_t target_node_id,
                                    uint8_t request_id,
                                    uint8_t result_code,
                                    uint8_t detail_code);
InfraStatus CanModule_QueueEvent(CanModule *module,
                                 uint8_t target_node_id,
                                 uint8_t event_code,
                                 uint8_t arg0,
                                 uint8_t arg1);
InfraStatus CanModule_QueueText(CanModule *module,
                                uint8_t target_node_id,
                                const char *text);
uint8_t     CanModule_TryPopIncoming(CanModule *module, CanMessage *out_message);
uint8_t     CanModule_TryPopResult(CanModule *module, CanServiceResult *out_result);

#endif
