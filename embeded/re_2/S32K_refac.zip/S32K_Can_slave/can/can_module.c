#include "can_module.h"

#include <stddef.h>
#include <string.h>

static InfraStatus CanModule_PushRequest(CanModule *module, const CanModuleRequest *request)
{
    if ((module == NULL) || (request == NULL) || (module->initialized == 0U))
    {
        return INFRA_STATUS_INVALID_ARG;
    }

    return InfraQueue_Push(&module->request_queue, request);
}

static void CanModule_SubmitPending(CanModule *module)
{
    CanModuleRequest request;
    uint8_t          submitted;
    uint8_t          send_ok;

    if ((module == NULL) || (module->initialized == 0U))
    {
        return;
    }

    submitted = 0U;
    while (submitted < module->max_submit_per_tick)
    {
        if (InfraQueue_Peek(&module->request_queue, &request) != INFRA_STATUS_OK)
        {
            break;
        }

        send_ok = 0U;
        switch (request.kind)
        {
            case CAN_MODULE_REQUEST_COMMAND:
                send_ok = CanService_SendCommand(&module->service,
                                                 request.target_node_id,
                                                 request.code0,
                                                 request.code1,
                                                 request.code2,
                                                 request.need_response);
                break;

            case CAN_MODULE_REQUEST_RESPONSE:
                send_ok = CanService_SendResponse(&module->service,
                                                  request.target_node_id,
                                                  request.code0,
                                                  request.code1,
                                                  request.code2);
                break;

            case CAN_MODULE_REQUEST_EVENT:
                send_ok = CanService_SendEvent(&module->service,
                                               request.target_node_id,
                                               request.code0,
                                               request.code1,
                                               request.code2);
                break;

            case CAN_MODULE_REQUEST_TEXT:
                send_ok = CanService_SendText(&module->service,
                                              request.target_node_id,
                                              CAN_TEXT_USER,
                                              request.text);
                break;

            default:
                send_ok = 1U;
                break;
        }

        if (send_ok == 0U)
        {
            break;
        }

        (void)InfraQueue_Pop(&module->request_queue, &request);
        submitted++;
    }

    if (submitted != 0U)
    {
        CanService_FlushTx(&module->service, module->service.current_tick_ms);
        module->last_activity = 1U;
    }
}

InfraStatus CanModule_Init(CanModule *module, const CanModuleConfig *config)
{
    if ((module == NULL) || (config == NULL))
    {
        return INFRA_STATUS_INVALID_ARG;
    }

    (void)memset(module, 0, sizeof(*module));
    module->local_node_id = config->local_node_id;
    module->default_target_node_id = config->default_target_node_id;
    module->max_submit_per_tick = config->max_submit_per_tick;
    if (module->max_submit_per_tick == 0U)
    {
        module->max_submit_per_tick = 2U;
    }

    if (InfraQueue_Init(&module->request_queue,
                        module->request_storage,
                        (uint16_t)sizeof(CanModuleRequest),
                        CAN_MODULE_REQUEST_QUEUE_SIZE) != INFRA_STATUS_OK)
    {
        return INFRA_STATUS_IO_ERROR;
    }

    if (CanService_Init(&module->service,
                        config->local_node_id,
                        config->default_timeout_ms) == 0U)
    {
        return INFRA_STATUS_IO_ERROR;
    }

    module->initialized = 1U;
    return INFRA_STATUS_OK;
}

void CanModule_Task(CanModule *module, uint32_t now_ms)
{
    if ((module == NULL) || (module->initialized == 0U))
    {
        return;
    }

    module->last_activity = 0U;
    CanService_Task(&module->service, now_ms);
    CanModule_SubmitPending(module);
}

InfraStatus CanModule_QueueCommand(CanModule *module,
                                   uint8_t target_node_id,
                                   uint8_t command_code,
                                   uint8_t arg0,
                                   uint8_t arg1,
                                   uint8_t need_response)
{
    CanModuleRequest request;

    (void)memset(&request, 0, sizeof(request));
    request.kind = CAN_MODULE_REQUEST_COMMAND;
    request.target_node_id = target_node_id;
    request.code0 = command_code;
    request.code1 = arg0;
    request.code2 = arg1;
    request.need_response = need_response;
    return CanModule_PushRequest(module, &request);
}

InfraStatus CanModule_QueueResponse(CanModule *module,
                                    uint8_t target_node_id,
                                    uint8_t request_id,
                                    uint8_t result_code,
                                    uint8_t detail_code)
{
    CanModuleRequest request;

    (void)memset(&request, 0, sizeof(request));
    request.kind = CAN_MODULE_REQUEST_RESPONSE;
    request.target_node_id = target_node_id;
    request.code0 = request_id;
    request.code1 = result_code;
    request.code2 = detail_code;
    return CanModule_PushRequest(module, &request);
}

InfraStatus CanModule_QueueEvent(CanModule *module,
                                 uint8_t target_node_id,
                                 uint8_t event_code,
                                 uint8_t arg0,
                                 uint8_t arg1)
{
    CanModuleRequest request;

    (void)memset(&request, 0, sizeof(request));
    request.kind = CAN_MODULE_REQUEST_EVENT;
    request.target_node_id = target_node_id;
    request.code0 = event_code;
    request.code1 = arg0;
    request.code2 = arg1;
    return CanModule_PushRequest(module, &request);
}

InfraStatus CanModule_QueueText(CanModule *module,
                                uint8_t target_node_id,
                                const char *text)
{
    CanModuleRequest request;

    if (text == NULL)
    {
        return INFRA_STATUS_INVALID_ARG;
    }

    (void)memset(&request, 0, sizeof(request));
    request.kind = CAN_MODULE_REQUEST_TEXT;
    request.target_node_id = target_node_id;
    (void)strncpy(request.text, text, CAN_TEXT_MAX_LEN);
    request.text[CAN_TEXT_MAX_LEN] = '\0';
    return CanModule_PushRequest(module, &request);
}

uint8_t CanModule_TryPopIncoming(CanModule *module, CanMessage *out_message)
{
    if (module == NULL)
    {
        return 0U;
    }

    return CanService_PopReceivedMessage(&module->service, out_message);
}

uint8_t CanModule_TryPopResult(CanModule *module, CanServiceResult *out_result)
{
    if (module == NULL)
    {
        return 0U;
    }

    return CanService_PopResult(&module->service, out_result);
}
