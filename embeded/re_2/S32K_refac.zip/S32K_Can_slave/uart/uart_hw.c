#include "uart_hw.h"

#include <stddef.h>

#include "sdk_project_config.h"

#ifdef INST_LPUART_1

static uint16_t UartHw_NextPendingIndex(uint16_t index)
{
    index++;
    if (index >= UART_RX_PENDING_SIZE)
    {
        index = 0U;
    }

    return index;
}

static uint8_t UartHw_IsPendingFull(const UartRxPendingRing *ring)
{
    uint16_t next_tail;

    if (ring == NULL)
    {
        return 1U;
    }

    next_tail = UartHw_NextPendingIndex(ring->tail);
    return (next_tail == ring->head) ? 1U : 0U;
}

static void UartHw_PushPendingByte(UartService *service, uint8_t rx_byte)
{
    UartRxPendingRing *ring;

    if (service == NULL)
    {
        return;
    }

    ring = &service->rx_pending;
    if (UartHw_IsPendingFull(ring) != 0U)
    {
        ring->overflow = 1U;
        ring->overflow_count++;
        return;
    }

    ring->buffer[ring->tail] = rx_byte;
    ring->tail = UartHw_NextPendingIndex(ring->tail);
}

static status_t UartHw_StartReceiveByte(UartService *service)
{
    if (service == NULL)
    {
        return STATUS_ERROR;
    }

    service->rx_byte = 0U;
    return LPUART_DRV_ReceiveData(service->instance, &service->rx_byte, 1U);
}

static status_t UartHw_ContinueReceiveByte(UartService *service)
{
    if (service == NULL)
    {
        return STATUS_ERROR;
    }

    service->rx_byte = 0U;
    return LPUART_DRV_SetRxBuffer(service->instance, &service->rx_byte, 1U);
}

status_t UartHw_InitDefault(UartService *service)
{
    status_t status;

    if (service == NULL)
    {
        return STATUS_ERROR;
    }

    /*
     * USER_PROJECT_BINDING_REQUIRED:
     * Update this file if the generated UART peripheral name changes.
     */
    service->instance = INST_LPUART_1;
    status = LPUART_DRV_Init(service->instance, &lpUartState1, &lpuart_1_InitConfig0);
    if (status != STATUS_SUCCESS)
    {
        return status;
    }

    (void)LPUART_DRV_InstallRxCallback(service->instance, UartHw_RxCallback, service);
    return UartHw_StartReceiveByte(service);
}

status_t UartHw_StartTransmit(UartService *service, const uint8_t *data, uint16_t length)
{
    if ((service == NULL) || (data == NULL) || (length == 0U))
    {
        return STATUS_ERROR;
    }

    return LPUART_DRV_SendData(service->instance, data, (uint32_t)length);
}

status_t UartHw_GetTransmitStatus(UartService *service, uint32_t *bytes_remaining)
{
    if (service == NULL)
    {
        return STATUS_ERROR;
    }

    return LPUART_DRV_GetTransmitStatus(service->instance, bytes_remaining);
}

void UartHw_RxCallback(void *driver_state, uart_event_t event, void *user_data)
{
    UartService *service;
    status_t     status;

    (void)driver_state;

    if (user_data == NULL)
    {
        return;
    }

    service = (UartService *)user_data;

    if (event == UART_EVENT_RX_FULL)
    {
        UartHw_PushPendingByte(service, service->rx_byte);
        status = UartHw_ContinueReceiveByte(service);
        if (status != STATUS_SUCCESS)
        {
            service->error_flag = 1U;
            service->error_code = UART_ERROR_RX_DRIVER;
            service->error_count++;
        }
        return;
    }

    if (event == UART_EVENT_ERROR)
    {
        service->error_flag = 1U;
        service->error_code = UART_ERROR_RX_DRIVER;
        service->error_count++;

        status = UartHw_ContinueReceiveByte(service);
        if (status != STATUS_SUCCESS)
        {
            service->error_count++;
        }
    }
}

#else

status_t UartHw_InitDefault(UartService *service)
{
    (void)service;
    return STATUS_ERROR;
}

status_t UartHw_StartTransmit(UartService *service, const uint8_t *data, uint16_t length)
{
    (void)service;
    (void)data;
    (void)length;
    return STATUS_ERROR;
}

status_t UartHw_GetTransmitStatus(UartService *service, uint32_t *bytes_remaining)
{
    (void)service;

    if (bytes_remaining != NULL)
    {
        *bytes_remaining = 0U;
    }

    return STATUS_ERROR;
}

void UartHw_RxCallback(void *driver_state, uart_event_t event, void *user_data)
{
    (void)driver_state;
    (void)event;
    (void)user_data;
}

#endif
