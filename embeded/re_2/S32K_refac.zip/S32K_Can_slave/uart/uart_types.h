#ifndef UART_TYPES_H
#define UART_TYPES_H

#include "infra/infra_queue.h"

#define UART_RX_LINE_SIZE            64U
#define UART_RX_PENDING_SIZE         32U
#define UART_TX_CHUNK_SIZE           128U
#define UART_TX_QUEUE_SIZE           8U
#define UART_DEFAULT_TIMEOUT_MS      100U

typedef enum
{
    UART_ERROR_NONE = 0,
    UART_ERROR_HW_INIT,
    UART_ERROR_RX_DRIVER,
    UART_ERROR_RX_PENDING_OVERFLOW,
    UART_ERROR_RX_LINE_OVERFLOW,
    UART_ERROR_TX_QUEUE_FULL,
    UART_ERROR_TX_DRIVER,
    UART_ERROR_TX_TIMEOUT
} UartErrorCode;

typedef struct
{
    uint8_t           buffer[UART_RX_PENDING_SIZE];
    volatile uint16_t head;
    volatile uint16_t tail;
    volatile uint8_t  overflow;
    volatile uint32_t overflow_count;
} UartRxPendingRing;

typedef struct
{
    char     buffer[UART_RX_LINE_SIZE];
    uint16_t length;
    uint8_t  line_ready;
    uint8_t  overflow;
} UartLineBuffer;

typedef struct
{
    uint8_t  data[UART_TX_CHUNK_SIZE];
    uint16_t length;
} UartTxChunk;

typedef struct
{
    char       current_buffer[UART_TX_CHUNK_SIZE + 1U];
    uint16_t   current_length;
    uint8_t    busy;
    uint32_t   start_ms;
    uint32_t   timeout_ms;
    InfraQueue queue;
    UartTxChunk queue_storage[UART_TX_QUEUE_SIZE];
} UartTxContext;

typedef struct
{
    uint8_t           initialized;
    uint32_t          instance;
    uint8_t           rx_byte;
    UartRxPendingRing rx_pending;
    UartLineBuffer    rx_line;
    UartTxContext     tx;
    uint8_t           error_flag;
    uint32_t          error_count;
    UartErrorCode     error_code;
} UartService;

#endif
