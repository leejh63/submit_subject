#ifndef UART_SERVICE_H
#define UART_SERVICE_H

#include "uart_types.h"

InfraStatus   UartService_Init(UartService *service);
InfraStatus   UartService_Recover(UartService *service);
void          UartService_ProcessRx(UartService *service);
void          UartService_ProcessTx(UartService *service, uint32_t now_ms);
InfraStatus   UartService_RequestTx(UartService *service, const char *text);
uint8_t       UartService_HasLine(const UartService *service);
InfraStatus   UartService_ReadLine(UartService *service, char *out_buffer, uint16_t max_length);
InfraStatus   UartService_GetCurrentInputText(const UartService *service,
                                              char *out_buffer,
                                              uint16_t max_length);
uint16_t      UartService_GetCurrentInputLength(const UartService *service);
uint16_t      UartService_GetTxQueueCount(const UartService *service);
uint16_t      UartService_GetTxQueueCapacity(const UartService *service);
uint8_t       UartService_IsTxBusy(const UartService *service);
uint8_t       UartService_HasError(const UartService *service);
UartErrorCode UartService_GetErrorCode(const UartService *service);

#endif
