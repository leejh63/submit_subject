#ifndef UART_HW_H
#define UART_HW_H

#include "uart_types.h"

#include "status.h"
#include "lpuart_driver.h"

status_t UartHw_InitDefault(UartService *service);
status_t UartHw_StartTransmit(UartService *service, const uint8_t *data, uint16_t length);
status_t UartHw_GetTransmitStatus(UartService *service, uint32_t *bytes_remaining);
void     UartHw_RxCallback(void *driver_state, uart_event_t event, void *user_data);

#endif
