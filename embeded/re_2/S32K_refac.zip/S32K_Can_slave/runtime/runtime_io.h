#ifndef RUNTIME_IO_H
#define RUNTIME_IO_H

#include "adc/adc_module.h"
#include "app/app_config.h"
#include "infra/infra_types.h"
#include "led/led_module.h"
#include "lin/lin_module.h"

InfraStatus RuntimeIo_BoardInit(void);
uint8_t     RuntimeIo_GetActiveRole(void);
uint8_t     RuntimeIo_GetLocalNodeId(void);

InfraStatus RuntimeIo_GetSlave1LedConfig(LedConfig *out_config);
InfraStatus RuntimeIo_GetSlave2LedConfig(LedConfig *out_config);
uint8_t     RuntimeIo_ReadSlave1ButtonPressed(void);

InfraStatus RuntimeIo_GetSlave2AdcConfig(AdcConfig *out_config);
InfraStatus RuntimeIo_GetMasterLinConfig(LinConfig *out_config);
InfraStatus RuntimeIo_GetSlaveLinConfig(LinConfig *out_config);
void        RuntimeIo_AttachLinModule(LinModule *module);
void        RuntimeIo_LinNotifyEvent(LinEventId event_id, uint8_t current_pid);

#endif
