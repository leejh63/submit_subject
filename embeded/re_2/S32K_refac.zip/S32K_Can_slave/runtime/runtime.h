#ifndef RUNTIME_H
#define RUNTIME_H

#include "app/app_core.h"
#include "infra/infra_types.h"

InfraStatus    Runtime_Init(void);
void           Runtime_Run(void);
const AppCore *Runtime_GetApp(void);

#endif
